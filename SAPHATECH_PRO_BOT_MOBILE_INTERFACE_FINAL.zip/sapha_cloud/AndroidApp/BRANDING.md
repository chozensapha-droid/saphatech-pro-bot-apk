# Saphatech Pro Bot branding

- App name: Saphatech Pro Bot
- Launcher icon: `app/src/main/res/drawable/saphatech_icon.png`
- Package: `com.saphatech.probot`
