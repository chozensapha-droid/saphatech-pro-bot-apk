# Saphatech Pro Bot Mobile Interface

Premium dark mobile trading interface based on the approved design.

Features shown in the mobile UI:
- Candle Movement strategy, M1
- BUY and SELL entry controls
- 0.02s (20 ms) Quick Exit target
- Target Profit display
- Risk controls
- Open positions and P/L
- Exness MT5 connection status
- Quick Exit All control
- Connect to PC Bot action

The mobile app is a controller/interface; MT5 order execution remains on the PC MT5 engine.
