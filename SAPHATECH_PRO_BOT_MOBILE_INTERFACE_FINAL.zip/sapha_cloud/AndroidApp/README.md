# SAPHATECH PRO BOT — AndroidApp

This is the Android controller for the PC-based SAPHATECH PRO BOT.

## Architecture
Android APK → local Wi‑Fi/LAN → Streamlit on PC (`0.0.0.0:8501`) → Python bot → MetaTrader 5.

The APK does **not** run the Python/MetaTrader 5 engine. The PC must stay powered on with MT5 logged in and the bot running.

## Build
1. Open this `AndroidApp` folder in Android Studio.
2. Allow Android Studio to install Android SDK 35 and the Android Gradle Plugin dependencies.
3. Select **Build → Build APK(s)**.
4. Install the resulting debug APK on the Android phone.

## Connect
1. Run `PC_BOT/START_FOR_ANDROID.bat` on the Windows PC.
2. Put phone and PC on the same trusted Wi‑Fi/LAN.
3. Enter `http://PC_IP:8501` in the app, e.g. `http://192.168.1.20:8501`.
4. Press **CONNECT BOT**.

Do not port-forward 8501 to the public internet.

## Cloud build

A GitHub Actions workflow is included at `.github/workflows/build-apk.yml`. It builds `app-debug.apk` automatically in the cloud; Android Studio is not required on the build machine.
