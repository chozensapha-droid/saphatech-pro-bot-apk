package com.saphatech.probot;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.View;

public class CandleChartView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    public CandleChartView(Context c, AttributeSet a){ super(c,a); p.setStrokeWidth(2f); }
    @Override protected void onDraw(Canvas c){
        super.onDraw(c); int w=getWidth(), h=getHeight();
        p.setColor(0x3317385A); p.setStrokeWidth(1f);
        for(int i=1;i<5;i++) c.drawLine(0,h*i/5f,w,h*i/5f,p);
        for(int i=1;i<8;i++) c.drawLine(w*i/8f,0,w*i/8f,h,p);
        float[] vals={.70f,.64f,.72f,.60f,.58f,.52f,.55f,.45f,.48f,.42f,.38f,.44f,.40f,.50f,.46f,.55f,.52f,.60f,.66f,.62f,.72f,.69f,.78f,.74f};
        float step=w/(vals.length+1f);
        p.setStrokeWidth(2f);
        Path ema=new Path();
        for(int i=0;i<vals.length;i++){
            float x=step*(i+1), y=vals[i]*h*.72f+h*.08f;
            float body=10, top=y-12, bot=y+12;
            p.setColor(i%4==0?0xFFFF3B4D:0xFF19E37A); p.setStrokeWidth(2f);
            c.drawLine(x,top,x,bot,p); c.drawRect(x-body/2, y-8, x+body/2, y+8,p);
            if(i==0) ema.moveTo(x,y+8); else ema.lineTo(x,y+8);
        }
        p.setColor(0xFF36A8FF); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3f); c.drawPath(ema,p); p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF19E37A); p.setTextSize(12); c.drawText("2327.71", w-62, h*.28f,p);
        p.setColor(0xFF8DA5B8); c.drawText("07:16        07:20        07:24", 14,h-10,p);
    }
}
