package com.saphatech.probot;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.graphics.Color;

public class MainActivity extends Activity {
    private TextView status;
    @Override public void onCreate(Bundle b){ super.onCreate(b); setContentView(R.layout.activity_main);
        status=findViewById(R.id.actionStatus);
        Button buy=findViewById(R.id.buyButton), sell=findViewById(R.id.sellButton), exit=findViewById(R.id.quickExitAll), connect=findViewById(R.id.connectPc);
        buy.setOnClickListener(v -> status.setText("BUY signal queued • Candle Movement • XAUUSD"));
        sell.setOnClickListener(v -> status.setText("SELL signal queued • Candle Movement • XAUUSD"));
        exit.setOnClickListener(v -> { status.setText("QUICK EXIT ALL requested • 0.02s target"); status.setTextColor(Color.rgb(255,210,210)); });
        connect.setOnClickListener(v -> { status.setText("Connecting to PC Bot… Configure the PC address in the PC dashboard/WebView build."); status.setTextColor(Color.rgb(141,165,184)); });
    }
}
