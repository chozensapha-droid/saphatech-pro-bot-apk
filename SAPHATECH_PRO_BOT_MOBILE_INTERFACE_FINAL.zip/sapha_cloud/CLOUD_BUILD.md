# SAPHATECH PRO BOT — Cloud APK Build

This project is prepared for a cloud build. No Android Studio is required on the user's device.

## GitHub Actions

1. Put this project in a GitHub repository.
2. Open the repository's **Actions** tab.
3. Select **Build SAPHATECH PRO BOT APK**.
4. Press **Run workflow**.
5. Wait for the build to finish.
6. Open the completed workflow run and download the **SAPHATECH-PRO-BOT-APK** artifact.
7. Extract the downloaded artifact and install `app-debug.apk` on Android.

The workflow automatically installs Java 17, Android SDK 35, Build Tools 35.0.0, and Gradle 8.7, then builds the debug APK.

## Important

The Android app is a controller for the PC bot. It does not contain the Python/MetaTrader 5 engine. The Windows PC must run the bot and MetaTrader 5, with the phone connected to the PC over trusted Wi-Fi/LAN.
