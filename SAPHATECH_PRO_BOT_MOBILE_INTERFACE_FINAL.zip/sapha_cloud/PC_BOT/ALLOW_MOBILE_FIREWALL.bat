@echo off
setlocal

echo Adding Windows Firewall rule for SAPHATECH PRO BOT mobile connection on TCP 8501...
netsh advfirewall firewall add rule name="SAPHATECH PRO BOT Mobile 8501" dir=in action=allow protocol=TCP localport=8501 profile=private
if errorlevel 1 (
  echo.
  echo FAILED. Right-click this file and choose "Run as administrator".
) else (
  echo.
  echo Firewall rule added successfully.
)
pause
endlocal
