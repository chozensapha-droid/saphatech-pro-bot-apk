@echo off
setlocal
cd /d "%~dp0trading_ai_v7"
echo ===== SAPHATECH PRO BOT CHECK =====
python --version
echo.
python -m streamlit --version
echo.
python -c "import streamlit; print('Streamlit import OK')"
echo.
pause
endlocal
