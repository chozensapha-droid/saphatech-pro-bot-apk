@echo off
setlocal
title SAPHATECH PRO BOT - INSTALL
cd /d "%~dp0trading_ai_v7"

where python >nul 2>&1
if errorlevel 1 (
  echo ERROR: Python is not installed or not in PATH.
  pause
  exit /b 1
)

if not exist "requirements.txt" (
  echo ERROR: requirements.txt is missing.
  pause
  exit /b 1
)

python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if errorlevel 1 (
  echo.
  echo Dependency installation failed.
  pause
  exit /b 1
)

echo.
echo Installation completed successfully.
echo Run START_SAPHATECH_PRO_BOT.bat from the main folder.
pause
endlocal
