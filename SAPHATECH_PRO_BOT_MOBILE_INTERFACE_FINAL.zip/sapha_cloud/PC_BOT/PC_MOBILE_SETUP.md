# SAPHATECH PRO BOT — PC + MOBILE

This package is one system with two interfaces:

- **PC:** Windows + Python + MetaTrader 5 + Exness run the trading engine.
- **Mobile:** Android controls the same Streamlit dashboard over the local Wi-Fi/LAN.

## PC

1. Install MetaTrader 5 and log in to Exness.
2. Enable **Algo Trading** in MT5.
3. Install Python 3.11+ if needed.
4. Run `START_SAPHATECH_PRO_BOT.bat` for normal PC use, or `START_FOR_ANDROID.bat` for PC + Android access.

## Android

1. Open `AndroidApp` in Android Studio.
2. Let Android Studio install the required SDK/build tools.
3. Build the APK from **Build > Build APK(s)**.
4. Install the APK on the Android phone.
5. Put the phone and PC on the same Wi-Fi.
6. Run `PC_BOT/START_FOR_ANDROID.bat` on the PC.
7. Read the PC IPv4 address shown in the console.
8. In the Android app enter `http://PC_IP:8501` and press **CONNECT BOT**.

Example: `http://192.168.1.20:8501`

## Firewall

If the phone cannot connect, right-click `ALLOW_MOBILE_FIREWALL.bat` and run it as Administrator.

## Important

The Android app is a controller/view for the PC bot. The PC must remain powered on, MT5 logged in, and the bot running for live trading commands to execute.

Do not expose port 8501 to the public internet or configure router port-forwarding for it. Use the same trusted local network.
