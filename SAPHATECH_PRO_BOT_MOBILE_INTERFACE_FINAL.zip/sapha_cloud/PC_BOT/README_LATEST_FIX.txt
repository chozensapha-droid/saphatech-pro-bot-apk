SAPHATECH PRO BOT - Latest Fix

Global live-position auto-close is ON by default at $6.00 per position on the
selected MT5 symbol. This applies to manual, existing, and SAPHATECH positions.
The dashboard includes an ON/OFF switch and target setting.

Other entry, countdown, re-entry, and broker filling-mode features are retained.
