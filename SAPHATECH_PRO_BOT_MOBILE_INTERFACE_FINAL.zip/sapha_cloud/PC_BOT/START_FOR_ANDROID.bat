@echo off
setlocal EnableExtensions
cd /d "%~dp0trading_ai_v7"
title SAPHATECH PRO BOT - PC + ANDROID SERVER

echo ================================================
echo SAPHATECH PRO BOT - PC + ANDROID MODE
echo ================================================
echo.

where python >nul 2>&1
if errorlevel 1 (
  echo ERROR: Python was not found.
  pause
  exit /b 1
)

echo Installing/updating bot requirements...
python -m pip install -r requirements.txt
if errorlevel 1 (
  echo ERROR: Dependency installation failed.
  pause
  exit /b 1
)

echo.
echo Your phone must be on the same Wi-Fi/LAN as this PC.
echo.
echo Available IPv4 addresses on this PC:
powershell -NoProfile -Command "Get-NetIPAddress -AddressFamily IPv4 -PrefixOrigin Dhcp,Manual | Where-Object {$_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*'} | Select-Object -ExpandProperty IPAddress"
echo.
echo The mobile app normally connects to:
echo     http://YOUR-PC-IP:8501
echo.
echo Keep this window open while using the mobile app.
echo If the phone cannot connect, run ALLOW_MOBILE_FIREWALL.bat as Administrator.
echo.
python -m streamlit run app.py --server.address 0.0.0.0 --server.port 8501 --server.headless true --browser.gatherUsageStats false

pause
endlocal
