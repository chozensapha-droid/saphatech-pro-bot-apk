@echo off
setlocal EnableExtensions
title SAPHATECH PRO BOT - AUTO ENTRY FIXED
cd /d "%~dp0trading_ai_v7"

echo ==========================================
echo SAPHATECH PRO BOT - AUTO ENTRY FIX
echo ==========================================
echo.

where python >nul 2>&1
if errorlevel 1 (
  echo ERROR: Python was not found.
  pause
  exit /b 1
)

echo Updating Streamlit to a version with native fragments...
python -m pip install --upgrade "streamlit>=1.37.0"
if errorlevel 1 (
  echo ERROR: Streamlit installation failed.
  pause
  exit /b 1
)

echo.
echo Installing all bot requirements...
python -m pip install -r requirements.txt
if errorlevel 1 (
  echo ERROR: Dependency installation failed.
  pause
  exit /b 1
)

echo.
echo Verifying Streamlit version...
python -c "import streamlit; print('Streamlit:', streamlit.__version__)"
if errorlevel 1 (
  echo ERROR: Streamlit cannot be imported.
  pause
  exit /b 1
)

echo.
echo Starting SAPHATECH PRO BOT...
echo AUTO LIVE ENTRY will check the selected symbol approximately every 2 seconds
echo after AUTO LIVE ENTRY is armed.
echo Keep this window open.
echo.

python -m streamlit run app.py --server.headless false --browser.gatherUsageStats false

echo.
echo BOT STOPPED.
pause
endlocal
