AUTO ENTRY + OPTIONAL COUNTDOWN

1. Enable AUTO LIVE ENTRY AT ENTRY POINT.
2. Click ARM AUTO LIVE ENTRY.
3. USE ENTRY COUNTDOWN is optional:
   - OFF: the bot enters immediately when live price reaches the calculated BUY/SELL trigger.
   - ON: the bot starts the selected countdown (1-30 seconds) when price reaches the trigger.
4. With countdown ON, price must remain at/through the trigger until zero. The bot re-checks live price immediately before sending the market order.
5. If price moves away before zero, the countdown is cancelled and waits for the trigger again.
6. A successful execution is marked for the current M5 candle; a rejected order is not marked successful.

The bot still requires a logged-in Exness MT5 terminal and broker-compatible order settings.
