# SAPHATECH PRO BOT v8 — Exness MT5 Live + Paper

Responsive Streamlit trading dashboard for PC and mobile browsers. Supports dynamic Exness/MT5 symbol selection (including XAUUSD, XAUAUD, GBPUSD, GBPJPY, AUDUSD, USOIL, BTCUSD and other symbols exposed by the terminal), with H1/M30/M15/M5 analysis, paper trading, and optional live execution through a MetaTrader 5 terminal logged into Exness.

**Live controls:** 5% maximum risk per trade, 10 maximum open positions, and 0.01–0.10 lot volume range.

## Start on Windows
1. Install MetaTrader 5 and log into your Exness account.
2. Install Python 3.11+.
3. In this folder:
   `pip install -r requirements.txt`
4. Run:
   `streamlit run app.py`

Read `EXNESS_LIVE_SETUP.md` before enabling live orders.


## Risk setting
Configured risk per trade: **10%**. This is an extremely high-risk setting and can cause rapid account losses. Use a demo account first and verify the broker symbol, contract size, stop-loss distance, and lot calculation before live trading.

## Single-symbol mode
The dashboard loads the available tradeable symbols from the connected MT5 terminal. Select exactly one symbol; the bot analyzes and opens new trades only for that selected symbol. Broker-specific Exness suffixes are preserved.


## Automatic position mode
AUTO POSITION MODE is enabled by default. For a confirmed BUY/SELL setup, the bot automatically chooses a position count from 1 up to the configured maximum. With 3/4 timeframe alignment it targets half the maximum (minimum 1); with 4/4 alignment it can target the full maximum. The configured risk percentage is divided across the positions opened in that batch.


AUTO ENTRY: The live tab provides AUTO LIVE ENTRY AT ENTRY POINT. Arm it deliberately after confirming the Exness account and risk settings. The bot then refreshes market data and can submit live orders automatically when the calculated entry trigger is reached.


## Profit target
The dashboard includes an optional AUTO-CLOSE AT PROFIT TARGET control with a
configurable target from $50 to $1,000 USD. It monitors SAPHATECH bot positions
on the selected symbol and attempts a market close when combined floating profit
plus swap reaches the target.

## Direct Python MT5 order helper

`live_mt5.py` now exposes `initialize_mt5()` and `send_mt5_order(symbol, action_type, volume, sl_pips=20, tp_pips=40)` for direct Python callers. The helper uses the connected MT5 terminal, broker symbol precision, BUY/SELL market pricing, pip-based SL/TP, and the SAPHATECH order comment/magic requested for this integration.

The bot's existing `place_market_order()` / `place_manual_market_order()` paths remain unchanged so their broker-aware filling-mode retries, risk sizing, and quick-exit behavior are preserved.
