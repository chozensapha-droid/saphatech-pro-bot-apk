import streamlit as st
import pandas as pd
import re
import time
from trading_ai import analyze_market, format_plan
from paper_engine import PaperEngine
try:
    from live_mt5 import account_info, get_frames, open_positions, bot_positions, close_all_positions_at_profit_target, place_market_order, place_manual_market_order, place_market_orders, shutdown, available_symbols, select_symbol
    mt5_available = True
except Exception:
    mt5_available = False
    account_info = get_frames = open_positions = bot_positions = close_all_positions_at_profit_target = place_market_order = place_manual_market_order = place_market_orders = shutdown = available_symbols = select_symbol = None

st.set_page_config(page_title="SAPHATECH PRO BOT", page_icon="📈", layout="wide", initial_sidebar_state="collapsed")
st.markdown("""
<style>
.block-container{padding-top:1rem;max-width:1400px}button{min-height:44px}
@media(max-width:700px){.block-container{padding:.7rem}h1{font-size:1.7rem}}
</style>
""", unsafe_allow_html=True)

if "engine" not in st.session_state:
    st.session_state.engine = PaperEngine(balance=10.0, risk_percent=10)
if "plan" not in st.session_state:
    st.session_state.plan = None
if "bot_running" not in st.session_state:
    st.session_state.bot_running = False
if "auto_entry_armed" not in st.session_state:
    st.session_state.auto_entry_armed = False
if "last_auto_entry_key" not in st.session_state:
    st.session_state.last_auto_entry_key = None
if "auto_entry_status" not in st.session_state:
    st.session_state.auto_entry_status = "Waiting for AUTO LIVE ENTRY check..."
if "entry_countdown_end" not in st.session_state:
    st.session_state.entry_countdown_end = None
if "entry_countdown_key" not in st.session_state:
    st.session_state.entry_countdown_key = None
if "entry_countdown_seconds" not in st.session_state:
    st.session_state.entry_countdown_seconds = 5
if "use_entry_countdown" not in st.session_state:
    st.session_state.use_entry_countdown = False
if "quick_entry_enabled" not in st.session_state:
    st.session_state.quick_entry_enabled = True
if "quick_entry_interval" not in st.session_state:
    st.session_state.quick_entry_interval = 0.25
if "manual_trade_requested" not in st.session_state:
    st.session_state.manual_trade_requested = False
if "manual_trade_key" not in st.session_state:
    st.session_state.manual_trade_key = None
if "manual_trade_countdown_end" not in st.session_state:
    st.session_state.manual_trade_countdown_end = None
if "manual_trade_side" not in st.session_state:
    st.session_state.manual_trade_side = None
if "manual_trade_lots" not in st.session_state:
    st.session_state.manual_trade_lots = 0.01
if "auto_changing_lots" not in st.session_state:
    st.session_state.auto_changing_lots = True
if "auto_lot_min" not in st.session_state:
    st.session_state.auto_lot_min = 0.01
if "auto_lot_max" not in st.session_state:
    st.session_state.auto_lot_max = 0.50
if "fixed_auto_lot" not in st.session_state:
    st.session_state.fixed_auto_lot = 0.01

def manual_order_levels(symbol, side, plan):
    """Build valid market-order SL/TP levels for either manual BUY or SELL."""
    import MetaTrader5 as _mt5
    tick = _mt5.symbol_info_tick(symbol)
    info = _mt5.symbol_info(symbol)
    if tick is None or info is None:
        raise RuntimeError(f"No live MT5 quote for {symbol}")
    side = side.upper()
    price = float(tick.ask if side == "BUY" else tick.bid)
    # Reuse the analyzed setup distance, but mirror it for the manually selected side.
    entry_ref = float(plan.entry) if plan.entry is not None else price
    sl_dist = abs(entry_ref - float(plan.stop_loss)) if plan.stop_loss is not None else 0.0
    tp_dist = abs(float(plan.take_profit_1) - entry_ref) if plan.take_profit_1 is not None else 0.0
    point = float(getattr(info, "point", 0.0) or 0.0)
    stops_level = int(getattr(info, "trade_stops_level", 0) or 0)
    min_dist = max(point * max(stops_level, 1), point * 10) if point > 0 else 0.0
    sl_dist = max(sl_dist, min_dist)
    tp_dist = max(tp_dist, min_dist)
    if side == "BUY":
        stop_price, tp_price = price - sl_dist, price + tp_dist
    elif side == "SELL":
        stop_price, tp_price = price + sl_dist, price - tp_dist
    else:
        raise ValueError("Side must be BUY or SELL")
    digits = int(getattr(info, "digits", 5) or 5)
    return round(stop_price, digits), round(tp_price, digits)
if "profit_target_status" not in st.session_state:
    st.session_state.profit_target_status = "Profit-target auto-close is waiting for bot positions..."
if "global_profit_close_enabled" not in st.session_state:
    st.session_state.global_profit_close_enabled = True
if "global_profit_close_usd" not in st.session_state:
    st.session_state.global_profit_close_usd = 6.0
if "global_random_profit_close" not in st.session_state:
    st.session_state.global_random_profit_close = False
if "global_random_profit_min" not in st.session_state:
    st.session_state.global_random_profit_min = 1.0
if "global_random_profit_max" not in st.session_state:
    st.session_state.global_random_profit_max = 6.0
if "quick_profit_exit_enabled" not in st.session_state:
    st.session_state.quick_profit_exit_enabled = True
if "quick_profit_exit_interval" not in st.session_state:
    st.session_state.quick_profit_exit_interval = 0.01
if "immediate_reentry_enabled" not in st.session_state:
    st.session_state.immediate_reentry_enabled = True
if "candle_movement_enabled" not in st.session_state:
    st.session_state.candle_movement_enabled = True
if "candle_timeframe" not in st.session_state:
    st.session_state.candle_timeframe = "M1"
if "candle_confirmations" not in st.session_state:
    st.session_state.candle_confirmations = 1
if "candle_min_body_percent" not in st.session_state:
    st.session_state.candle_min_body_percent = 0.0
if "reentry_status" not in st.session_state:
    st.session_state.reentry_status = "Immediate re-entry after target-profit exit is ready."
if "reentry_auto_lot_change" not in st.session_state:
    st.session_state.reentry_auto_lot_change = True
if "reentry_lot_step" not in st.session_state:
    st.session_state.reentry_lot_step = 0.01
if "reentry_custom_lot_sequence" not in st.session_state:
    st.session_state.reentry_custom_lot_sequence = "0.02,0.05,0.03,0.06,0.04,0.08,0.10"
if "reentry_sequence_index" not in st.session_state:
    # The initial entry is 0.01; the first replacement after it closes is 0.02.
    st.session_state.reentry_sequence_index = 0

st.title("📈 SAPHATECH PRO BOT — Exness MT5")
st.caption("Dynamic Exness/MT5 symbols • Single-symbol analysis/trading | H1 → M30 → M15 → M5")
st.caption("Auto-changing lot range: 0.01–0.50 lots • broker limits/step still apply")

with st.sidebar:
    st.header("Risk controls")
    risk = st.number_input("Risk per trade (%)", min_value=0.1, max_value=10.0, value=10.0, step=0.1)
    max_positions = st.number_input("Max open positions", min_value=1, max_value=10, value=10, step=1)
    auto_positions = st.checkbox("AUTO POSITION MODE (1 → Max)", value=True, help="Automatically selects the number of positions from the confirmed multi-timeframe signal, up to Max open positions.")
    auto_changing_lots = st.checkbox(
        "AUTO CHANGING LOTS",
        value=bool(st.session_state.auto_changing_lots),
        help="ON: each automatic trade calculates its lot from account equity, risk and stop distance, then clamps it to your lot range. This can change the lot size from one trade to the next. OFF: automatic trades use the fixed lot below."
    )
    st.session_state.auto_changing_lots = bool(auto_changing_lots)
    lc1, lc2 = st.columns(2)
    with lc1:
        auto_lot_min = st.number_input(
            "AUTO LOT MIN", min_value=0.01, max_value=0.50,
            value=float(st.session_state.auto_lot_min), step=0.01, format="%.2f",
            help="Minimum lot used by automatic risk-based sizing."
        )
    with lc2:
        auto_lot_max = st.number_input(
            "AUTO LOT MAX", min_value=0.01, max_value=0.50,
            value=float(st.session_state.auto_lot_max), step=0.01, format="%.2f",
            help="Maximum lot used by automatic risk-based sizing."
        )
    auto_lot_min = min(float(auto_lot_min), float(auto_lot_max))
    auto_lot_max = max(float(auto_lot_min), float(auto_lot_max))
    st.session_state.auto_lot_min = auto_lot_min
    st.session_state.auto_lot_max = auto_lot_max
    if not auto_changing_lots:
        fixed_auto_lot = st.number_input(
            "FIXED AUTO LOT", min_value=0.01, max_value=0.50,
            value=float(st.session_state.fixed_auto_lot), step=0.01, format="%.2f",
            help="Lot size for automatic entries when AUTO CHANGING LOTS is OFF."
        )
        st.session_state.fixed_auto_lot = float(fixed_auto_lot)
    auto_entry = st.checkbox("AUTO LIVE ENTRY", value=True, help="When armed, a confirmed signal can enter immediately when Quick Live Entry is ON, or wait for the calculated trigger when Quick Live Entry is OFF.")
    use_entry_countdown = st.checkbox(
        "USE ENTRY COUNTDOWN",
        value=bool(st.session_state.use_entry_countdown),
        help="OFF: enter immediately when price reaches the entry trigger. ON: start a countdown and enter only after it reaches zero while price is still at/through the trigger."
    )
    st.session_state.use_entry_countdown = bool(use_entry_countdown)
    quick_entry_enabled = st.checkbox(
        "⚡ QUICK LIVE ENTRY",
        value=bool(st.session_state.quick_entry_enabled),
        help="ON: confirmed BUY/SELL signal is submitted immediately at the current MT5 market price. It bypasses the entry-price trigger and the optional entry countdown.",
    )
    st.session_state.quick_entry_enabled = bool(quick_entry_enabled)
    if quick_entry_enabled:
        quick_entry_interval = st.number_input(
            "QUICK ENTRY CHECK (seconds)", min_value=0.25, max_value=2.0,
            value=float(st.session_state.quick_entry_interval), step=0.05, format="%.2f",
            help="How often the live signal is checked while Quick Live Entry is armed.",
        )
        st.session_state.quick_entry_interval = float(quick_entry_interval)

    st.markdown("### CANDLE MOVEMENT ENTRY")
    candle_movement_enabled = st.checkbox(
        "🕯️ CANDLE MOVEMENT MODE",
        value=bool(st.session_state.candle_movement_enabled),
        help="Automatic entries are allowed only when the selected closed candle(s) confirm BUY or SELL direction. The current forming candle is never used as the entry signal."
    )
    st.session_state.candle_movement_enabled = bool(candle_movement_enabled)
    cc1, cc2 = st.columns(2)
    with cc1:
        candle_timeframe = st.selectbox(
            "CANDLE SIGNAL TIMEFRAME", ["M1", "M5", "M15", "M30"],
            index=["M1", "M5", "M15", "M30"].index(st.session_state.candle_timeframe)
            if st.session_state.candle_timeframe in ["M1", "M5", "M15", "M30"] else 1,
            help="The bot reads the last fully closed candle(s) on this timeframe for BUY/SELL direction."
        )
        st.session_state.candle_timeframe = candle_timeframe
    with cc2:
        candle_confirmations = st.number_input(
            "CLOSED CANDLES REQUIRED", min_value=1, max_value=3,
            value=int(st.session_state.candle_confirmations), step=1,
            help="Number of consecutive closed candles that must point in the same direction."
        )
        st.session_state.candle_confirmations = int(candle_confirmations)
    candle_min_body_percent = st.number_input(
        "MINIMUM CANDLE BODY (%)", min_value=0.0, max_value=100.0,
        value=float(st.session_state.candle_min_body_percent), step=5.0,
        help="0% accepts any non-doji directional candle. Higher values require a stronger candle body relative to its full high-low range."
    )
    st.session_state.candle_min_body_percent = float(candle_min_body_percent)
    st.caption(
        "Candle mode: " + ("ON" if candle_movement_enabled else "OFF") +
        f" | signal {candle_timeframe} | {int(candle_confirmations)} closed candle(s) | body ≥ {float(candle_min_body_percent):.0f}%"
    )

    st.markdown("### BOT CONTROL")
    c_start, c_stop = st.columns(2)
    with c_start:
        if st.button("▶ START BOT", type="primary", use_container_width=True):
            st.session_state.bot_running = True
            st.session_state.auto_entry_armed = False
            st.session_state.last_auto_entry_key = None
            st.session_state.entry_countdown_end = None
            st.session_state.entry_countdown_key = None
            st.session_state.manual_trade_requested = False
            st.session_state.manual_trade_side = None
            st.session_state.manual_trade_key = None
            st.session_state.manual_trade_countdown_end = None
            st.session_state.last_auto_entry_time = 0.0
            st.session_state.auto_entry_status = "Bot started. Arm AUTO LIVE ENTRY when ready."
            st.session_state.profit_target_status = "Profit-target auto-close is active for SAPHATECH bot positions."
            st.session_state.reentry_status = "Immediate re-entry is ready after target-profit exits."
            st.rerun()
    with c_stop:
        if st.button("⏹ STOP BOT", use_container_width=True):
            st.session_state.bot_running = False
            st.session_state.auto_entry_armed = False
            st.session_state.entry_countdown_end = None
            st.session_state.entry_countdown_key = None
            st.session_state.manual_trade_requested = False
            st.session_state.manual_trade_side = None
            st.session_state.manual_trade_key = None
            st.session_state.manual_trade_countdown_end = None
            st.session_state.last_auto_entry_time = 0.0
            st.session_state.auto_entry_status = "Bot stopped. No automatic entries will be submitted."
            st.session_state.profit_target_status = "Bot stopped. Profit-target auto-close is paused."
            st.session_state.reentry_status = "Bot stopped. Immediate re-entry is paused."
            st.rerun()
    st.success("BOT STATUS: RUNNING" if st.session_state.bot_running else "BOT STATUS: STOPPED")
    if use_entry_countdown:
        entry_countdown_seconds = st.number_input(
            "ENTRY COUNTDOWN (seconds)", min_value=1, max_value=30, value=int(st.session_state.entry_countdown_seconds), step=1,
            help="After price reaches the calculated entry trigger, the bot waits this many seconds. The price must remain at/through the trigger for the countdown to complete."
        )
        st.session_state.entry_countdown_seconds = int(entry_countdown_seconds)
    else:
        st.caption("Entry countdown: OFF — immediate entry at trigger")

    st.markdown("### PROFIT TARGET")
    global_profit_close_enabled = st.checkbox(
        "AUTO-CLOSE PROFITABLE BOT POSITIONS",
        value=bool(st.session_state.global_profit_close_enabled),
        help="When ON, SAPHATECH bot positions on the selected symbol are monitored continuously and closed individually when their floating profit + swap reaches the target.",
    )
    st.session_state.global_profit_close_enabled = bool(global_profit_close_enabled)

    quick_profit_exit_enabled = st.checkbox(
        "⚡ QUICK PROFIT EXIT",
        value=bool(st.session_state.quick_profit_exit_enabled),
        help="When ON, profit checks run at a fast interval and the bot sends the market-close request before optional advisory validation.",
    )
    st.session_state.quick_profit_exit_enabled = bool(quick_profit_exit_enabled)
    if quick_profit_exit_enabled:
        quick_profit_exit_interval = st.number_input(
            "QUICK EXIT CHECK (seconds)", min_value=0.01, max_value=2.0,
            value=float(st.session_state.quick_profit_exit_interval), step=0.05, format="%.2f"
        )
        st.session_state.quick_profit_exit_interval = float(quick_profit_exit_interval)

    global_profit_close_usd = st.number_input(
        "PROFIT TARGET (USD)", min_value=0.10, max_value=1000.0,
        value=max(0.10, float(st.session_state.get("global_profit_close_usd", 6.0))), step=0.10,
        help="Per-position automatic profit target from $0.10 to $1,000.",
    )
    st.session_state.global_profit_close_usd = max(0.10, float(global_profit_close_usd))

    global_random_profit_close = st.checkbox(
        "RANDOM PROFIT TARGET",
        value=bool(st.session_state.global_random_profit_close),
        help="When ON, each SAPHATECH bot position receives one random target between the selected minimum and maximum. The target stays fixed for that ticket until it closes.",
    )
    st.session_state.global_random_profit_close = bool(global_random_profit_close)
    if global_random_profit_close:
        cmin, cmax = st.columns(2)
        with cmin:
            global_random_profit_min = st.number_input(
                "RANDOM MIN (USD)", min_value=0.10, max_value=1000.0,
                value=max(0.10, float(st.session_state.get("global_random_profit_min", 1.0))), step=0.10
            )
        with cmax:
            global_random_profit_max = st.number_input(
                "RANDOM MAX (USD)", min_value=0.10, max_value=1000.0,
                value=max(0.10, float(st.session_state.get("global_random_profit_max", 6.0))), step=0.10
            )
        if global_random_profit_max < global_random_profit_min:
            global_random_profit_max = global_random_profit_min
        st.session_state.global_random_profit_min = float(global_random_profit_min)
        st.session_state.global_random_profit_max = float(global_random_profit_max)
        st.caption(
            f"Random target: ${global_random_profit_min:,.2f}–${global_random_profit_max:,.2f} per position | "
            f"{'ON' if global_profit_close_enabled else 'OFF'}"
        )
    else:
        st.caption(
            f"Fixed target: ${global_profit_close_usd:,.2f} per position | "
            f"{'ON' if global_profit_close_enabled else 'OFF'}"
        )

    st.markdown("### RE-ENTRY")
    immediate_reentry_enabled = st.checkbox(
        "IMMEDIATE RE-ENTRY AFTER TARGET EXIT",
        value=bool(st.session_state.immediate_reentry_enabled),
        help="After a SAPHATECH bot position is closed by the profit target, immediately re-analyze the selected symbol and replace the closed position when the same BUY/SELL signal is still valid. No cooldown is used."
    )
    st.session_state.immediate_reentry_enabled = bool(immediate_reentry_enabled)

    reentry_auto_lot_change = st.checkbox(
        "AUTO CHANGE LOT ON RE-ENTRY",
        value=bool(st.session_state.reentry_auto_lot_change),
        help="After a profitable target exit, the replacement position uses the closed position's lot plus the step below. The next lot is capped at AUTO LOT MAX."
    )
    st.session_state.reentry_auto_lot_change = bool(reentry_auto_lot_change)
    reentry_lot_step = st.number_input(
        "RE-ENTRY LOT STEP", min_value=0.01, max_value=0.50,
        value=float(st.session_state.reentry_lot_step), step=0.01, format="%.2f",
        disabled=not reentry_auto_lot_change,
        help="Example: 0.01 closes -> next re-entry 0.02 -> then 0.03, up to AUTO LOT MAX."
    )
    st.session_state.reentry_lot_step = float(reentry_lot_step)
    reentry_custom_lot_sequence = st.text_input(
        "CUSTOM RE-ENTRY LOT SEQUENCE",
        value=str(st.session_state.reentry_custom_lot_sequence),
        disabled=not reentry_auto_lot_change,
        help="Comma-separated lots used after each profitable close. Example: 0.02,0.05,0.03,0.06,0.04,0.08,0.10. After the last value, the last lot is repeated.",
    )
    st.session_state.reentry_custom_lot_sequence = reentry_custom_lot_sequence
    st.caption("Sequence: 0.01 → 0.02 → 0.05 → 0.03 → 0.06 → 0.04 → 0.08 → 0.10")

    if mt5_available:
        try:
            dynamic_symbols = available_symbols()
        except Exception:
            dynamic_symbols = []
    else:
        dynamic_symbols = []

    fallback_symbols = ["XAUUSD", "XAUAUD", "GBPUSD", "GBPJPY", "AUDUSD", "USOIL", "BTCUSD"]
    symbol_options = dynamic_symbols or fallback_symbols
    saved_symbol = st.session_state.get("selected_symbol")
    default_symbol = saved_symbol if saved_symbol in symbol_options else symbol_options[0]

    symbol = st.selectbox(
        "MT5 symbol — select ONE",
        symbol_options,
        index=symbol_options.index(default_symbol),
        key="selected_symbol",
        help="The bot analyzes and trades only the currently selected symbol."
    )
    st.success(f"ACTIVE SYMBOL: {symbol}")
    st.caption("Single-symbol mode: only the selected instrument is analyzed and used for new trades.")
    st.caption("AUTO POSITION MODE: " + ("ON — 1 → Max Positions" if auto_positions else "OFF — one order per execution"))
    st.caption("AUTO LIVE ENTRY: " + ("ARMED" if st.session_state.auto_entry_armed else "OFF"))
    st.session_state.engine.risk_percent = risk
    st.warning("10% risk is very high. Test on an Exness demo account first and verify the settings before live trading.")

# Live MT5 status

live_tab, paper_tab, history_tab = st.tabs(["🔴 LIVE MT5", "🧪 PAPER", "📒 History"])

with live_tab:
    st.subheader("Exness MT5")
    st.info("Live orders use the MT5 terminal already logged into your Exness account. This app does not store your broker password.")
    if auto_entry and mt5_available and st.session_state.bot_running:
        st.warning("AUTO LIVE ENTRY can place real-money orders without pressing an order button. Use an Exness demo account first.")
        c_arm, c_disarm = st.columns(2)
        with c_arm:
            if st.button("🔐 ARM AUTO LIVE ENTRY", type="primary", use_container_width=True, disabled=not st.session_state.bot_running):
                st.session_state.auto_entry_armed = True
                st.session_state.last_auto_entry_key = None
                st.session_state.entry_countdown_end = None
                st.session_state.entry_countdown_key = None
                st.rerun()
        with c_disarm:
            if st.button("🛑 DISARM AUTO ENTRY", use_container_width=True):
                st.session_state.auto_entry_armed = False
                st.session_state.entry_countdown_end = None
                st.session_state.entry_countdown_key = None
                st.rerun()
        if st.session_state.auto_entry_armed:
            st.caption("AUTO LIVE ENTRY is armed; QUICK LIVE ENTRY enters immediately on a confirmed BUY/SELL signal when enabled.")
    col1, col2 = st.columns(2)
    with col1:
        if mt5_available and st.button("🔄 Connect / Refresh MT5", use_container_width=True):
            try:
                acct = account_info()
                st.success(f"Connected: login {acct.login} | equity {acct.equity:.2f} {acct.currency}")
            except Exception as e:
                st.error(str(e))
    with col2:
        if mt5_available and st.button("🛑 CLOSE APP / STOP", use_container_width=True):
            try: shutdown()
            except Exception: pass
            st.warning("MT5 connection closed. Existing broker positions are not managed by this bot.")

    if mt5_available:
        if st.button("🔄 Refresh Exness Symbol List", use_container_width=True):
            try:
                fresh = available_symbols()
                st.success(f"Loaded {len(fresh)} tradeable symbols from the connected MT5 terminal.")
            except Exception as e:
                st.error(str(e))

        if st.button("📡 Get Live Market Data + Analyze", use_container_width=True):
            try:
                select_symbol(symbol)
                frames = get_frames(symbol)
                acct = account_info()
                st.session_state.plan = analyze_market(frames, float(acct.equity), risk, symbol, candle_movement=bool(st.session_state.get("candle_movement_enabled", True)), candle_confirmations=int(st.session_state.get("candle_confirmations", 1)), min_body_percent=float(st.session_state.get("candle_min_body_percent", 0.0)), candle_timeframe=str(st.session_state.get("candle_timeframe", "M1")))
                st.success("Live market data analyzed.")
            except Exception as e:
                st.error(str(e))

        # Profit-target manager. This only manages SAPHATECH bot positions.
        # A successful target exit can immediately trigger a same-direction re-entry
        # after fresh market analysis, without waiting for the 2-second entry cycle.
        def _profit_target_check():
            try:
                if not st.session_state.bot_running or not global_profit_close_enabled:
                    return

                before_positions = {}
                try:
                    for p in bot_positions(symbol):
                        ticket = int(getattr(p, "ticket", 0) or 0)
                        if ticket:
                            ptype = int(getattr(p, "type", -1))
                            before_positions[ticket] = {
                                "side": "BUY" if ptype == 0 else "SELL",
                                "volume": float(getattr(p, "volume", 0.01) or 0.01),
                            }
                except Exception:
                    before_positions = {}

                global_result = close_all_positions_at_profit_target(
                    None,
                    global_profit_close_usd,
                    random_target=bool(global_random_profit_close),
                    random_min=float(st.session_state.get("global_random_profit_min", 1.0)),
                    random_max=float(st.session_state.get("global_random_profit_max", 6.0)),
                )
                st.session_state.profit_target_status = global_result.message

                # Detect a real target exit by comparing bot tickets before/after the close call.
                closed_sides = []
                closed_records = []
                try:
                    after_tickets = {
                        int(getattr(p, "ticket", 0) or 0)
                        for p in bot_positions(symbol)
                        if int(getattr(p, "ticket", 0) or 0)
                    }
                    for ticket, info in before_positions.items():
                        if ticket not in after_tickets:
                            closed_sides.append(info["side"])
                            closed_records.append({"ticket": ticket, **info})
                except Exception:
                    closed_sides = []
                    closed_records = []

                if global_result.ok:
                    st.success("AUTO-CLOSE: " + global_result.message)

                if closed_sides and st.session_state.get("immediate_reentry_enabled", True):
                    try:
                        # Fresh analysis immediately after the profit exit.
                        select_symbol(symbol)
                        frames = get_frames(symbol)
                        acct = account_info()
                        reentry_plan = analyze_market(frames, float(acct.equity), risk, symbol, candle_movement=bool(st.session_state.get("candle_movement_enabled", True)), candle_confirmations=int(st.session_state.get("candle_confirmations", 1)), min_body_percent=float(st.session_state.get("candle_min_body_percent", 0.0)), candle_timeframe=str(st.session_state.get("candle_timeframe", "M1")))
                        desired_side = reentry_plan.decision if reentry_plan.decision in ("BUY", "SELL") else None
                        match = re.search(r"(\d+)/4", reentry_plan.reason)
                        signal_strength = int(match.group(1)) if match else 3
                        matching_records = [r for r in closed_records if r["side"] == desired_side] if desired_side else []
                        matching_exits = len(matching_records)

                        if matching_exits and reentry_plan.stop_loss is not None and reentry_plan.take_profit_1 is not None:
                            # Keep the configured risk as a batch budget when replacing multiple exits.
                            replacement_risk = float(risk) / max(1, matching_exits)
                            opened = 0
                            errors = []
                            next_lots = []
                            for closed_record in matching_records:
                                old_lot = float(closed_record.get("volume", 0.01))
                                auto_change = bool(st.session_state.get("reentry_auto_lot_change", True))
                                lot_max = float(st.session_state.get("auto_lot_max", 0.50))
                                lot_min = float(st.session_state.get("auto_lot_min", 0.01))
                                if auto_change:
                                    # Custom progression requested by the user. The first original entry
                                    # remains 0.01; each profitable re-entry consumes the next value.
                                    raw_seq = str(st.session_state.get("reentry_custom_lot_sequence", "0.02,0.05,0.03,0.06,0.04,0.08,0.10"))
                                    try:
                                        sequence = [float(x.strip()) for x in raw_seq.split(",") if x.strip()]
                                        sequence = [x for x in sequence if x > 0]
                                    except Exception:
                                        sequence = []
                                    idx = int(st.session_state.get("reentry_sequence_index", 0))
                                    if sequence:
                                        next_lot = sequence[min(idx, len(sequence) - 1)]
                                        st.session_state.reentry_sequence_index = idx + 1
                                    else:
                                        step = float(st.session_state.get("reentry_lot_step", 0.01))
                                        next_lot = old_lot + step
                                    next_lot = min(lot_max, max(lot_min, next_lot))
                                else:
                                    next_lot = old_lot
                                next_lots.append(next_lot)
                                result = place_market_order(
                                    symbol,
                                    desired_side,
                                    reentry_plan.stop_loss,
                                    reentry_plan.take_profit_1,
                                    replacement_risk,
                                    int(max_positions),
                                    comment=f"SAPHATECH PRO BOT REENTRY {desired_side}",
                                    auto_lot=False if auto_change else bool(st.session_state.get("auto_changing_lots", True)),
                                    fixed_volume=next_lot if auto_change else float(st.session_state.get("fixed_auto_lot", 0.01)),
                                    lot_min=lot_min,
                                    lot_max=lot_max,
                                )
                                if result.ok:
                                    opened += 1
                                else:
                                    errors.append(result.message)
                                    break

                            if opened:
                                # Reset the candle gate so a successful replacement does not block the new cycle.
                                st.session_state.last_auto_entry_key = None
                                lot_text = ", ".join(f"{x:.2f}" for x in next_lots) if next_lots else "n/a"
                                lot_mode = "CUSTOM AUTO LOT SEQUENCE" if bool(st.session_state.get("reentry_auto_lot_change", True)) else "same lot"
                                st.session_state.reentry_status = (
                                    f"IMMEDIATE RE-ENTRY: {opened} {desired_side} position(s) reopened after target-profit exit | "
                                    f"{lot_mode} | next lot(s): {lot_text}"
                                )
                                st.success(st.session_state.reentry_status)
                                if errors:
                                    st.warning("RE-ENTRY stopped after broker/risk rejection: " + errors[0])
                            else:
                                st.session_state.reentry_status = (
                                    f"IMMEDIATE RE-ENTRY failed: {errors[0] if errors else 'no replacement order was opened.'}"
                                )
                                st.error(st.session_state.reentry_status)
                        else:
                            st.session_state.reentry_status = (
                                f"TARGET EXIT DETECTED: {len(closed_sides)} position(s) closed; current signal is "
                                f"{reentry_plan.decision}. No same-direction replacement was sent."
                            )
                            st.info(st.session_state.reentry_status)
                    except Exception as reentry_error:
                        st.session_state.reentry_status = "IMMEDIATE RE-ENTRY ERROR: " + str(reentry_error)
                        st.error(st.session_state.reentry_status)
                elif closed_sides:
                    st.session_state.reentry_status = "Target-profit exit detected. Immediate re-entry is OFF."

            except Exception as e:
                st.session_state.profit_target_status = "PROFIT TARGET: " + str(e)
                st.error(st.session_state.profit_target_status)

        # Automatic analysis/entry loop. A deliberate ARM action is required
        # before any live order can be submitted automatically.
        def _auto_entry_check():
            try:
                select_symbol(symbol)
                frames = get_frames(symbol)
                acct = account_info()
                live_plan = analyze_market(frames, float(acct.equity), risk, symbol, candle_movement=bool(st.session_state.get("candle_movement_enabled", True)), candle_confirmations=int(st.session_state.get("candle_confirmations", 1)), min_body_percent=float(st.session_state.get("candle_min_body_percent", 0.0)), candle_timeframe=str(st.session_state.get("candle_timeframe", "M1")))
                st.session_state.plan = live_plan
                now = time.time()

                if live_plan.decision not in ("BUY", "SELL") or live_plan.entry is None:
                    st.session_state.auto_entry_status = (
                        f"Checked {symbol}: {live_plan.decision} | waiting for a confirmed BUY/SELL signal."
                    )
                    return

                tick = __import__("MetaTrader5").symbol_info_tick(symbol)
                if tick is None:
                    st.session_state.auto_entry_status = f"Checked {symbol}: no live MT5 quote."
                    return

                live_price = float(tick.ask if live_plan.decision == "BUY" else tick.bid)
                reached = (
                    live_price >= float(live_plan.entry)
                    if live_plan.decision == "BUY"
                    else live_price <= float(live_plan.entry)
                )
                match = re.search(r"(\d+)/4", live_plan.reason)
                signal_strength = int(match.group(1)) if match else 3
                signal_tf = str(st.session_state.get("candle_timeframe", "M1")).upper()
                candle_key = str(frames[signal_tf].index[-1])
                entry_key = f"{symbol}|{live_plan.decision}|{signal_tf}|{candle_key}"
                quick_entry = bool(st.session_state.get("quick_entry_enabled", False))

                if entry_key == st.session_state.last_auto_entry_key:
                    st.session_state.auto_entry_status = (
                        f"Entry already sent for this {live_plan.decision}."
                    )
                    return

                # QUICK LIVE ENTRY: submit immediately when a confirmed signal is present.
                # It intentionally bypasses the calculated entry-price trigger and countdown.
                if quick_entry:
                    st.session_state.entry_countdown_end = None
                    st.session_state.entry_countdown_key = None
                    st.session_state.auto_entry_status = (
                        f"⚡ QUICK ENTRY: {live_plan.decision} signal confirmed | live {live_price:.5f}"
                    )
                    if auto_positions:
                        result = place_market_orders(
                            symbol, live_plan.decision, live_plan.stop_loss,
                            live_plan.take_profit_1, risk, int(max_positions), signal_strength,
                            auto_lot=bool(st.session_state.get("auto_changing_lots", True)),
                            fixed_volume=float(st.session_state.get("fixed_auto_lot", 0.01)),
                            lot_min=float(st.session_state.get("auto_lot_min", 0.01)),
                            lot_max=float(st.session_state.get("auto_lot_max", 0.50)),
                        )
                    else:
                        result = place_market_order(
                            symbol, live_plan.decision, live_plan.stop_loss,
                            live_plan.take_profit_1, risk, int(max_positions),
                            auto_lot=bool(st.session_state.get("auto_changing_lots", True)),
                            fixed_volume=float(st.session_state.get("fixed_auto_lot", 0.01)),
                            lot_min=float(st.session_state.get("auto_lot_min", 0.01)),
                            lot_max=float(st.session_state.get("auto_lot_max", 0.50)),
                        )
                    if result.ok:
                        st.session_state.last_auto_entry_key = entry_key
                        st.session_state.last_auto_entry_time = time.time()
                    (st.success if result.ok else st.error)("QUICK ENTRY: " + result.message)
                    return

                # Normal entry path: wait for the calculated trigger price.
                if reached:
                    countdown_enabled = bool(st.session_state.use_entry_countdown)
                    if not countdown_enabled:
                        st.session_state.entry_countdown_end = None
                        st.session_state.entry_countdown_key = None
                        st.caption(
                            f"⚡ AUTO ENTRY TRIGGERED: {live_plan.decision} | "
                            f"live {live_price:.5f} | trigger {float(live_plan.entry):.5f}"
                        )
                        if auto_positions:
                            result = place_market_orders(
                                symbol, live_plan.decision, live_plan.stop_loss,
                                live_plan.take_profit_1, risk, int(max_positions), signal_strength,
                                auto_lot=bool(st.session_state.get("auto_changing_lots", True)),
                                fixed_volume=float(st.session_state.get("fixed_auto_lot", 0.01)),
                                lot_min=float(st.session_state.get("auto_lot_min", 0.01)),
                                lot_max=float(st.session_state.get("auto_lot_max", 0.50)),
                            )
                        else:
                            result = place_market_order(
                                symbol, live_plan.decision, live_plan.stop_loss,
                                live_plan.take_profit_1, risk, int(max_positions),
                                auto_lot=bool(st.session_state.get("auto_changing_lots", True)),
                                fixed_volume=float(st.session_state.get("fixed_auto_lot", 0.01)),
                                lot_min=float(st.session_state.get("auto_lot_min", 0.01)),
                                lot_max=float(st.session_state.get("auto_lot_max", 0.50)),
                            )
                        if result.ok:
                            st.session_state.last_auto_entry_key = entry_key
                            st.session_state.last_auto_entry_time = time.time()
                        (st.success if result.ok else st.error)("AUTO ENTRY: " + result.message)
                        return

                    # Countdown-enabled trigger entry.
                    if (
                        st.session_state.entry_countdown_key != entry_key
                        or st.session_state.entry_countdown_end is None
                    ):
                        st.session_state.entry_countdown_key = entry_key
                        st.session_state.entry_countdown_end = now + int(st.session_state.entry_countdown_seconds)

                    remaining = max(0.0, float(st.session_state.entry_countdown_end) - now)
                    if remaining > 0:
                        st.info(
                            f"⏳ ENTRY COUNTDOWN: {remaining:.1f}s | {live_plan.decision} | "
                            f"live {live_price:.5f} | trigger {float(live_plan.entry):.5f}"
                        )
                        return

                    confirm_tick = __import__("MetaTrader5").symbol_info_tick(symbol)
                    confirm_price = (
                        None if confirm_tick is None
                        else float(confirm_tick.ask if live_plan.decision == "BUY" else confirm_tick.bid)
                    )
                    still_reached = (
                        confirm_price is not None
                        and (
                            confirm_price >= float(live_plan.entry)
                            if live_plan.decision == "BUY"
                            else confirm_price <= float(live_plan.entry)
                        )
                    )
                    if not still_reached:
                        st.session_state.entry_countdown_end = None
                        st.session_state.entry_countdown_key = None
                        st.warning("ENTRY COUNTDOWN cancelled: price moved away before execution.")
                        return

                    if auto_positions:
                        result = place_market_orders(
                            symbol, live_plan.decision, live_plan.stop_loss,
                            live_plan.take_profit_1, risk, int(max_positions), signal_strength,
                            auto_lot=bool(st.session_state.get("auto_changing_lots", True)),
                            fixed_volume=float(st.session_state.get("fixed_auto_lot", 0.01)),
                            lot_min=float(st.session_state.get("auto_lot_min", 0.01)),
                            lot_max=float(st.session_state.get("auto_lot_max", 0.50)),
                        )
                    else:
                        result = place_market_order(
                            symbol, live_plan.decision, live_plan.stop_loss,
                            live_plan.take_profit_1, risk, int(max_positions),
                            auto_lot=bool(st.session_state.get("auto_changing_lots", True)),
                            fixed_volume=float(st.session_state.get("fixed_auto_lot", 0.01)),
                            lot_min=float(st.session_state.get("auto_lot_min", 0.01)),
                            lot_max=float(st.session_state.get("auto_lot_max", 0.50)),
                        )
                    if result.ok:
                        st.session_state.last_auto_entry_key = entry_key
                        st.session_state.last_auto_entry_time = time.time()
                    st.session_state.entry_countdown_end = None
                    st.session_state.entry_countdown_key = None
                    (st.success if result.ok else st.error)("AUTO ENTRY AFTER COUNTDOWN: " + result.message)
                    return

                if st.session_state.entry_countdown_key == entry_key:
                    st.session_state.entry_countdown_end = None
                    st.session_state.entry_countdown_key = None
                st.session_state.auto_entry_status = (
                    f"AUTO ENTRY watching {live_plan.decision}: live {live_price:.5f} | "
                    f"trigger {float(live_plan.entry):.5f}"
                )
            except Exception as e:
                st.session_state.auto_entry_status = "AUTO ENTRY: " + str(e)
                st.error(st.session_state.auto_entry_status)

        # Automatic profit closing is independent of AUTO ENTRY.
        # While the bot is running, the profit manager checks open SAPHATECH
        # positions about once per second and can close qualifying positions.
        if global_profit_close_enabled and st.session_state.bot_running:
            _profit_fragment = getattr(st, "fragment", None)
            if _profit_fragment is not None:
                _interval = float(st.session_state.get("quick_profit_exit_interval", 0.10)) if st.session_state.get("quick_profit_exit_enabled", True) else 0.50
                _profit_fragment_runner = _profit_fragment(run_every=f"{_interval:.2f}s")(_profit_target_check)
                _profit_fragment_runner()
            else:
                _profit_target_check()
            st.caption("AUTO-CLOSE STATUS: " + st.session_state.profit_target_status)
            st.caption(
                "⚡ QUICK EXIT: " + (
                    f"ON — checks about every {float(st.session_state.get('quick_profit_exit_interval', 0.01)):.2f}s"
                    if st.session_state.get("quick_profit_exit_enabled", True)
                    else "OFF — normal monitoring interval"
                )
            )
            st.caption("RE-ENTRY STATUS: " + st.session_state.get("reentry_status", "Immediate re-entry ready."))
            try:
                _open_count = len(open_positions(None))
                _bot_count = len(bot_positions(None))
                st.caption(f"MT5 positions: {_open_count} total | {_bot_count} SAPHATECH-managed")
            except Exception:
                pass

        if auto_entry and st.session_state.bot_running and st.session_state.auto_entry_armed:
            _fragment = getattr(st, "fragment", None)
            if _fragment is not None:
                _entry_interval = float(st.session_state.get("quick_entry_interval", 0.25)) if st.session_state.get("quick_entry_enabled", False) else 2.0
                _auto_entry_fragment = _fragment(run_every=f"{_entry_interval:.2f}s")(_auto_entry_check)
                _auto_entry_fragment()
            else:
                _auto_entry_check()
            if st.session_state.get("auto_entry_status"):
                st.caption("AUTO ENTRY STATUS: " + st.session_state.auto_entry_status)
            if st.session_state.get("entry_countdown_end") is not None:
                remaining = max(0.0, float(st.session_state.entry_countdown_end) - time.time())
                if remaining > 0:
                    st.progress(min(1.0, remaining / max(1, int(st.session_state.entry_countdown_seconds))))
                    st.caption(f"ENTRY COUNTDOWN ACTIVE: {remaining:.1f}s remaining")

    if st.session_state.plan:
        st.code(format_plan(st.session_state.plan))

    # Manual market trading is independent of the AI plan.
    st.error("LIVE MANUAL TRADE ZONE")
    st.caption("Manual BUY/SELL sends one market order for the selected symbol. It does not require START BOT, an AI signal, or an entry trigger. MT5 Algo Trading must still be enabled for programmatic live orders.")
    mcol1, mcol2, mcol3 = st.columns(3)
    with mcol1:
        manual_lots = st.number_input(
            "Manual lot size", min_value=0.01, max_value=0.50,
            value=float(st.session_state.get("manual_trade_lots", 0.01)), step=0.01, format="%.2f",
            key="manual_trade_lots_input",
            help="The broker may enforce a smaller maximum or different step for the selected symbol."
        )
    with mcol2:
        manual_use_levels = st.checkbox(
            "USE ANALYZED SL/TP", value=bool(st.session_state.plan),
            disabled=st.session_state.plan is None,
            help="When an AI plan exists, use mirrored valid SL/TP levels. Turn off to send the manual order without SL/TP."
        )
    with mcol3:
        manual_countdown = st.checkbox(
            "MANUAL COUNTDOWN", value=False,
            help="OFF: enter immediately. ON: wait for the configured entry countdown, then send at the live market price."
        )

    manual_confirmation = st.text_input('Type LIVE to enable MANUAL TRADE', type="password", key="manual_trade_confirmation")
    manual_disabled = not (mt5_available and manual_confirmation.strip().upper() == "LIVE")
    mbuy, msell = st.columns(2)
    with mbuy:
        manual_buy_clicked = st.button("🟢 MANUAL BUY", type="primary", use_container_width=True, disabled=manual_disabled)
    with msell:
        manual_sell_clicked = st.button("🔴 MANUAL SELL", type="primary", use_container_width=True, disabled=manual_disabled)

    manual_side = "BUY" if manual_buy_clicked else ("SELL" if manual_sell_clicked else None)
    if manual_side:
        st.session_state.manual_trade_requested = True
        st.session_state.manual_trade_side = manual_side
        st.session_state.manual_trade_key = f"{symbol}|{manual_side}|{time.time_ns()}"
        st.session_state.manual_trade_lots = float(manual_lots)
        if manual_countdown:
            st.session_state.manual_trade_countdown_end = time.time() + int(st.session_state.entry_countdown_seconds)
            st.session_state.manual_trade_manual_levels = bool(manual_use_levels)
            st.info(f"⏳ MANUAL {manual_side} countdown started: {st.session_state.entry_countdown_seconds}s")
            st.rerun()
        else:
            try:
                stop_price = tp_price = 0.0
                if manual_use_levels and st.session_state.plan:
                    stop_price, tp_price = manual_order_levels(symbol, manual_side, st.session_state.plan)
                result = place_manual_market_order(
                    symbol, manual_side, float(manual_lots), stop_price, tp_price,
                    comment=f"SAPHATECH PRO BOT MANUAL {manual_side}"
                )
                (st.success if result.ok else st.error)(f"MANUAL {manual_side}: " + result.message)
            except Exception as e:
                st.error(f"MANUAL {manual_side}: " + str(e))
            finally:
                st.session_state.manual_trade_requested = False
                st.session_state.manual_trade_side = None
                st.session_state.manual_trade_key = None
                st.session_state.manual_trade_countdown_end = None

    if st.session_state.get("manual_trade_requested") and st.session_state.get("manual_trade_countdown_end") is not None:
        countdown_side = st.session_state.get("manual_trade_side")
        remaining = max(0.0, float(st.session_state.manual_trade_countdown_end) - time.time())
        if remaining > 0:
            st.info(f"⏳ MANUAL {countdown_side} COUNTDOWN: {remaining:.1f}s remaining — order will be sent at market after 0")
            st.progress(min(1.0, remaining / max(1, int(st.session_state.entry_countdown_seconds))))
        else:
            try:
                stop_price = tp_price = 0.0
                if st.session_state.get("manual_trade_manual_levels") and st.session_state.plan:
                    stop_price, tp_price = manual_order_levels(symbol, countdown_side, st.session_state.plan)
                result = place_manual_market_order(
                    symbol, countdown_side, float(st.session_state.get("manual_trade_lots", 0.01)),
                    stop_price, tp_price, comment=f"SAPHATECH PRO BOT MANUAL {countdown_side}"
                )
                (st.success if result.ok else st.error)(f"MANUAL {countdown_side} AFTER COUNTDOWN: " + result.message)
            except Exception as e:
                st.error(f"MANUAL {countdown_side}: " + str(e))
            finally:
                st.session_state.manual_trade_requested = False
                st.session_state.manual_trade_side = None
                st.session_state.manual_trade_key = None
                st.session_state.manual_trade_countdown_end = None

        _fragment = getattr(st, "fragment", None)
        if _fragment is not None and st.session_state.get("manual_trade_requested"):
            def _manual_trade_tick():
                if st.session_state.get("manual_trade_requested") and st.session_state.get("manual_trade_countdown_end") is not None:
                    remaining_inner = max(0.0, float(st.session_state.manual_trade_countdown_end) - time.time())
                    if remaining_inner > 0:
                        st.rerun(scope="fragment")
                    else:
                        st.rerun()
            _manual_fragment = _fragment(run_every="0.25s")(_manual_trade_tick)
            _manual_fragment()

        if mt5_available and st.button("📋 Refresh Open Positions", use_container_width=True):
            try:
                pos = open_positions(symbol)
                st.dataframe(pd.DataFrame([p._asdict() if hasattr(p, "_asdict") else p._asdict() for p in pos]) if pos else pd.DataFrame(), use_container_width=True)
            except Exception as e:
                st.error(str(e))

with paper_tab:
    st.subheader("Paper account")
    stats = st.session_state.engine.stats()
    c1,c2,c3=st.columns(3)
    c1.metric("Balance", f"{stats['balance']:.2f}")
    c2.metric("Trades", stats['trades'])
    c3.metric("Win rate", f"{stats['win_rate']:.1f}%")
    if st.session_state.plan and st.session_state.plan.decision in ("BUY","SELL"):
        if st.button("🧪 Open PAPER Trade", use_container_width=True):
            st.success(st.session_state.engine.maybe_open(st.session_state.plan, spread_points=20))
    if st.session_state.engine.open_trade:
        st.json(st.session_state.engine.open_trade.__dict__)
    else: st.info("No open paper position.")

with history_tab:
    if st.session_state.engine.history:
        st.dataframe(pd.DataFrame(st.session_state.engine.history), use_container_width=True, hide_index=True)
    else: st.info("No closed paper trades yet.")

st.divider()
st.caption("LIVE MODE sends orders through MetaTrader 5. Use demo first. The app cannot guarantee execution price, fills, or maximum loss during fast markets/gaps.")

# SAPHATECH PRO BOT: profit quick-check target interval (10 ms).
PROFIT_QUICK_CHECK_INTERVAL = 0.01