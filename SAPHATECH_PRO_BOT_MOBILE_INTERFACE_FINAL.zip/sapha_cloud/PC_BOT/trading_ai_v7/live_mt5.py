"""MT5 live-data and live-order adapter for the SAPHATECH PRO BOT.

Safety: the MT5 terminal must already be logged into the intended Exness account.
No broker password is stored by this app.
"""
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Optional
import math
import random

import MetaTrader5 as mt5
import pandas as pd

TF_MAP = {"M1": mt5.TIMEFRAME_M1, "M5": mt5.TIMEFRAME_M5, "M15": mt5.TIMEFRAME_M15, "M30": mt5.TIMEFRAME_M30, "H1": mt5.TIMEFRAME_H1}
BOT_MAGIC = 26092301
BOT_COMMENT_MARKER = "SAPHATECH"
MIN_BOT_LOT = 0.01
MAX_BOT_LOT = 0.50

# MT5 order comments are limited to the broker/terminal field size.
# Keep comments conservative so Python order_send cannot fail with
# "Invalid \"comment\" argument" before the request reaches the broker.
def _safe_trade_comment(value: object, fallback: str = "SAPHATECH") -> str:
    text = str(value or fallback).replace("\x00", " ").strip() or fallback
    # MT5 commonly enforces a 31-character order-comment field.
    # Restrict to 31 Unicode characters for a safe request.
    return text[:31]

@dataclass
class LiveOrderResult:
    ok: bool
    message: str
    ticket: Optional[int] = None


def connect() -> None:
    """Initialize MT5 only when the terminal is not already connected.

    Re-initializing on every quick-exit poll adds avoidable latency to live
    position management.
    """
    try:
        if mt5.terminal_info() is not None:
            return
    except Exception:
        pass
    if not mt5.initialize():
        raise RuntimeError(f"MT5 initialize failed: {mt5.last_error()}")


def shutdown() -> None:
    mt5.shutdown()


def initialize_mt5() -> bool:
    """Initialize the MetaTrader 5 terminal for direct Python order calls."""
    try:
        if mt5.terminal_info() is not None:
            print("MT5 Connected Successfully.")
            return True
    except Exception:
        pass

    if not mt5.initialize():
        print(f"MT5 Initialization failed, error code: {mt5.last_error()}")
        return False
    print("MT5 Connected Successfully.")
    return True


def send_mt5_order(symbol: str, action_type: str, volume: float, sl_pips: float = 20,
                   tp_pips: float = 40):
    """Send a BUY/SELL market order using the supplied pip-based SL/TP distances.

    This is a lightweight compatibility helper for callers that want the exact
    Python MT5 order interface requested for SAPHATECH. The main bot execution
    paths continue to use their existing broker-aware filling/risk handling.
    """
    if not initialize_mt5():
        return None

    symbol = str(symbol).strip()
    action = str(action_type).upper().strip()
    try:
        volume = float(volume)
        sl_pips = float(sl_pips)
        tp_pips = float(tp_pips)
    except (TypeError, ValueError):
        print("Invalid volume, SL pips, or TP pips.")
        return None

    if volume <= 0 or sl_pips < 0 or tp_pips < 0:
        print("Volume must be positive and pip distances cannot be negative.")
        return None

    if not mt5.symbol_select(symbol, True):
        print(f"Failed to select symbol {symbol}")
        return None

    symbol_info = mt5.symbol_info(symbol)
    tick = mt5.symbol_info_tick(symbol)
    if symbol_info is None or tick is None:
        print(f"Could not retrieve market info or ticks for {symbol}")
        return None

    point = float(symbol_info.point)
    digits = int(getattr(symbol_info, "digits", 5) or 5)
    pip_size = point * 10 if digits in (3, 5) else point

    if action == "BUY":
        order_type = mt5.ORDER_TYPE_BUY
        price = float(tick.ask)
        sl = price - sl_pips * pip_size if sl_pips > 0 else 0.0
        tp = price + tp_pips * pip_size if tp_pips > 0 else 0.0
    elif action == "SELL":
        order_type = mt5.ORDER_TYPE_SELL
        price = float(tick.bid)
        sl = price + sl_pips * pip_size if sl_pips > 0 else 0.0
        tp = price - tp_pips * pip_size if tp_pips > 0 else 0.0
    else:
        print(f"Invalid trade direction specified: {action_type}")
        return None

    sl = round(sl, digits) if sl else 0.0
    tp = round(tp, digits) if tp else 0.0

    request = {
        "action": mt5.TRADE_ACTION_DEAL,
        "symbol": symbol,
        "volume": volume,
        "type": order_type,
        "price": price,
        "sl": sl,
        "tp": tp,
        "deviation": 20,
        "magic": 234000,
        "comment": _safe_trade_comment(f"Saphatech {action} Bot"),
        "type_time": mt5.ORDER_TIME_GTC,
        "type_filling": mt5.ORDER_FILLING_IOC,
    }

    result = mt5.order_send(request)
    if result is None:
        print(f"Order Execution Failed ({action}): {mt5.last_error()}")
        return None

    if result.retcode != mt5.TRADE_RETCODE_DONE:
        print(f"Order Execution Failed ({action}): {result.comment} [Code: {result.retcode}]")
    else:
        print(f"SUCCESS: Placed {action} order | Ticket: {result.order or result.deal} | Price: {price}")

    return result


def available_symbols(include_hidden=False):
    """Return symbols exposed by the connected MT5 terminal.

    Exness can use broker-specific suffixes, so the exact MT5 symbol name is
    preserved. The dashboard can therefore select any symbol available in the
    connected terminal instead of relying on a hard-coded list.
    """
    connect()
    symbols = mt5.symbols_get()
    if symbols is None:
        raise RuntimeError(f"Could not read MT5 symbols: {mt5.last_error()}")

    rows = []
    for s in symbols:
        name = getattr(s, "name", "")
        if not name:
            continue
        # Prefer tradeable/visible symbols, while allowing hidden symbols when
        # explicitly requested.
        visible = bool(getattr(s, "visible", True))
        trade_mode = getattr(s, "trade_mode", None)
        if not include_hidden and not visible:
            continue
        disabled = getattr(mt5, "SYMBOL_TRADE_MODE_DISABLED", None)
        if disabled is not None and trade_mode == disabled:
            continue
        rows.append(name)

    return sorted(set(rows), key=str.upper)


def select_symbol(symbol: str) -> str:
    """Select exactly the requested MT5 symbol and return its exact name."""
    connect()
    symbol = str(symbol).strip()
    if not symbol:
        raise ValueError("A symbol must be selected.")
    if not mt5.symbol_select(symbol, True):
        raise RuntimeError(f"Could not select symbol {symbol}. Check MT5 Market Watch.")
    return symbol

def account_info():
    connect()
    info = mt5.account_info()
    if info is None:
        raise RuntimeError(f"Could not read MT5 account: {mt5.last_error()}")
    return info


def get_frames(symbol: str, bars: int = 200):
    select_symbol(symbol)
    out = {}
    for name, tf in TF_MAP.items():
        rates = mt5.copy_rates_from_pos(symbol, tf, 0, bars)
        if rates is None or len(rates) < 60:
            raise RuntimeError(f"Not enough {name} candles for {symbol}.")
        df = pd.DataFrame(rates)
        df["timestamp"] = pd.to_datetime(df["time"], unit="s")
        df = df.set_index("timestamp")
        out[name] = df[["open", "high", "low", "close", "tick_volume"]].rename(columns={"tick_volume": "volume"})
    return out


def open_positions(symbol: Optional[str] = None):
    connect()
    positions = mt5.positions_get(symbol=symbol) if symbol else mt5.positions_get()
    return list(positions or [])


def is_bot_position(position) -> bool:
    """Identify SAPHATECH positions robustly across MT5/Exness account modes.

    New orders use BOT_MAGIC and a SAPHATECH comment. On some netting setups
    the position magic/comment can reflect the most recent deal, so accept
    either bot marker rather than relying on magic alone. Unrelated/manual
    positions without the SAPHATECH marker remain excluded.
    """
    magic = int(getattr(position, "magic", 0) or 0)
    comment = str(getattr(position, "comment", "") or "").upper()
    return magic == BOT_MAGIC or BOT_COMMENT_MARKER in comment


def bot_positions(symbol: Optional[str] = None):
    """Return SAPHATECH positions using magic OR the SAPHATECH comment marker."""
    return [p for p in open_positions(symbol) if is_bot_position(p)]


def bot_open_profit(symbol: Optional[str] = None) -> float:
    """Return current floating profit + swap for bot-managed positions."""
    return sum(
        float(getattr(p, "profit", 0.0) or 0.0) + float(getattr(p, "swap", 0.0) or 0.0)
        for p in bot_positions(symbol)
    )


def close_bot_positions(symbol: Optional[str] = None, deviation: int = 50) -> LiveOrderResult:
    """Close all SAPHATECH positions for the selected symbol at market."""
    connect()
    positions = bot_positions(symbol)
    if not positions:
        return LiveOrderResult(False, "No SAPHATECH positions to close.")

    closed = 0
    errors = []
    for position in positions:
        symbol_name = str(getattr(position, "symbol", symbol or ""))
        tick = mt5.symbol_info_tick(symbol_name)
        if tick is None:
            errors.append(f"{symbol_name} ticket {position.ticket}: no live tick")
            continue

        if int(position.type) == int(mt5.POSITION_TYPE_BUY):
            order_type = mt5.ORDER_TYPE_SELL
            price = float(tick.bid)
        else:
            order_type = mt5.ORDER_TYPE_BUY
            price = float(tick.ask)

        base_request = {
            "action": mt5.TRADE_ACTION_DEAL,
            "symbol": symbol_name,
            "volume": float(position.volume),
            "type": order_type,
            "position": int(position.ticket),
            "price": price,
            "deviation": deviation,
            "magic": BOT_MAGIC,
            "comment": "SAPHATECH PRO BOT PROFIT TARGET",
            "type_time": mt5.ORDER_TIME_GTC,
        }

        sent = False
        fill_errors = []
        for fill_mode in _allowed_fill_modes(symbol_name):
            request = dict(base_request, type_filling=fill_mode)
            check = mt5.order_check(request)
            if check is None:
                fill_errors.append(f"fill={fill_mode}: order_check failed: {mt5.last_error()}")
                continue
            check_code = getattr(check, "retcode", 0)
            if check_code not in (0, mt5.TRADE_RETCODE_DONE):
                fill_errors.append(f"fill={fill_mode}: pre-check retcode={check_code}, comment={getattr(check, 'comment', '')}")
                continue

            result = mt5.order_send(request)
            if result is not None and result.retcode == mt5.TRADE_RETCODE_DONE:
                closed += 1
                sent = True
                break
            if result is None:
                fill_errors.append(f"fill={fill_mode}: order_send failed: {mt5.last_error()}")
            else:
                fill_errors.append(f"fill={fill_mode}: retcode={result.retcode}, comment={result.comment}")

        if not sent:
            errors.append(f"ticket {position.ticket}: " + " | ".join(fill_errors))

    if closed and not errors:
        return LiveOrderResult(True, f"PROFIT TARGET: closed {closed} bot position(s) on {symbol or 'selected symbol'}.")
    if closed and errors:
        return LiveOrderResult(True, f"PROFIT TARGET: closed {closed} position(s), but some closes failed: {errors[0]}")
    return LiveOrderResult(False, "PROFIT TARGET close failed: " + (errors[0] if errors else "unknown error"))


# Each small-lot position receives one random target when first seen.
# The target then stays fixed for that ticket until the position closes.
_RANDOM_TARGET_MIN_USD = 1.00
_RANDOM_TARGET_MAX_USD = 6.00
_RANDOM_POSITION_TARGETS = {}
_RANDOM_GLOBAL_TARGETS = {}


def per_position_profit_target(volume: float, ticket: Optional[int] = None,
                               random_min: float = _RANDOM_TARGET_MIN_USD,
                               random_max: float = _RANDOM_TARGET_MAX_USD) -> Optional[float]:
    """Return a per-position floating-profit target for a lot size.

    0.01–0.09 lots -> random target between ``random_min`` and ``random_max`` USD.
    The random target is assigned once per position ticket and remains fixed
    until that position closes.
    0.10–0.50 lots -> fixed $2.04.
    """
    v = float(volume)
    if 0.01 - 1e-9 <= v <= 0.09 + 1e-9:
        lo = max(0.01, float(random_min))
        hi = max(lo, float(random_max))
        if ticket is not None:
            key = int(ticket)
            if key not in _RANDOM_POSITION_TARGETS:
                _RANDOM_POSITION_TARGETS[key] = round(random.uniform(lo, hi), 2)
            return _RANDOM_POSITION_TARGETS[key]
        return round(random.uniform(lo, hi), 2)
    if 0.10 - 1e-9 <= v <= 0.50 + 1e-9:
        return 2.04
    return None


def _close_position_at_market(position, deviation: int = 500) -> tuple[bool, str]:
    """Close one MT5 position robustly, retrying broker-supported filling modes."""
    symbol_name = str(getattr(position, "symbol", "") or "")
    ticket = int(getattr(position, "ticket", 0) or 0)
    volume = float(getattr(position, "volume", 0.0) or 0.0)
    if not symbol_name or ticket <= 0 or volume <= 0:
        return False, f"ticket {ticket}: invalid position data"

    info = mt5.symbol_info(symbol_name)
    tick = mt5.symbol_info_tick(symbol_name)
    if info is None or tick is None:
        return False, f"ticket {ticket}: no live quote for {symbol_name}"

    if not bool(getattr(info, "visible", True)):
        try:
            mt5.symbol_select(symbol_name, True)
        except Exception:
            pass
        tick = mt5.symbol_info_tick(symbol_name)
        if tick is None:
            return False, f"ticket {ticket}: symbol {symbol_name} is not available in Market Watch"

    position_type = int(getattr(position, "type", -1))
    if position_type == int(mt5.POSITION_TYPE_BUY):
        order_type = mt5.ORDER_TYPE_SELL
        price = float(tick.bid)
    elif position_type == int(mt5.POSITION_TYPE_SELL):
        order_type = mt5.ORDER_TYPE_BUY
        price = float(tick.ask)
    else:
        return False, f"ticket {ticket}: unknown position type {position_type}"

    if price <= 0:
        return False, f"ticket {ticket}: invalid market price"

    terminal = mt5.terminal_info()
    account = mt5.account_info()
    if terminal is not None and hasattr(terminal, "trade_allowed") and not terminal.trade_allowed:
        return False, "MT5 AutoTrading is disabled in the terminal"
    if account is not None and hasattr(account, "trade_allowed") and not account.trade_allowed:
        return False, "MT5 trading is disabled for this account"

    base_request = {
        "action": mt5.TRADE_ACTION_DEAL,
        "symbol": symbol_name,
        "volume": volume,
        "type": order_type,
        "position": ticket,
        "price": price,
        "deviation": int(max(1, deviation)),
        "magic": BOT_MAGIC,
        "comment": _safe_trade_comment("SAPHATECH AUTO CLOSE"),
        "type_time": mt5.ORDER_TIME_GTC,
    }

    errors = []
    # QUICK EXIT: send the live close request first. order_check can add latency
    # and on some Exness/MT5 builds can reject a mode that order_send actually accepts.
    for fill_mode in _allowed_fill_modes(symbol_name):
        request = dict(base_request, type_filling=fill_mode)
        result = mt5.order_send(request)
        if result is None:
            errors.append(f"fill={fill_mode}: order_send failed: {mt5.last_error()}")
            continue

        retcode = int(getattr(result, "retcode", -1))
        comment = str(getattr(result, "comment", "") or "")
        if retcode in (
            getattr(mt5, "TRADE_RETCODE_DONE", 10009),
            getattr(mt5, "TRADE_RETCODE_DONE_PARTIAL", 10010),
            getattr(mt5, "TRADE_RETCODE_PLACED", 10008),
        ):
            return True, f"ticket {ticket}: QUICK EXIT accepted (retcode={retcode}, fill={fill_mode}, comment={comment})"

        errors.append(f"fill={fill_mode}: retcode={retcode}, comment={comment}")
        if retcode == getattr(mt5, "TRADE_RETCODE_INVALID_FILL", 10030):
            continue

    # Only after all fast live attempts fail, run advisory checks to expose a
    # useful diagnostic; the next monitoring cycle will retry automatically.
    for fill_mode in _allowed_fill_modes(symbol_name):
        request = dict(base_request, type_filling=fill_mode)
        check = mt5.order_check(request)
        if check is not None:
            check_code = int(getattr(check, "retcode", 0) or 0)
            check_comment = str(getattr(check, "comment", "") or "")
            if check_code not in (0, getattr(mt5, "TRADE_RETCODE_DONE", 10009)):
                errors.append(f"fill={fill_mode}: pre-check retcode={check_code}, comment={check_comment}")

    return False, f"ticket {ticket}: QUICK EXIT failed | " + " | ".join(errors[-8:])


def _quick_close_position_at_market(position, deviation: int = 1000) -> tuple[bool, str]:
    """Fast-path close for live profit exits.

    This path intentionally skips account/terminal checks and pre-checks. MT5\n    is the authority for trade permission, and every extra round trip here adds\n    latency after the target has already been reached. The normal close routine\n    remains available for diagnostics/fallbacks.
    """
    symbol_name = str(getattr(position, "symbol", "") or "")
    ticket = int(getattr(position, "ticket", 0) or 0)
    volume = float(getattr(position, "volume", 0.0) or 0.0)
    if not symbol_name or ticket <= 0 or volume <= 0:
        return False, f"ticket {ticket}: invalid position data"

    tick = mt5.symbol_info_tick(symbol_name)
    if tick is None:
        return False, f"ticket {ticket}: no live quote for {symbol_name}"

    ptype = int(getattr(position, "type", -1))
    if ptype == int(mt5.POSITION_TYPE_BUY):
        order_type = mt5.ORDER_TYPE_SELL
        price = float(tick.bid)
    elif ptype == int(mt5.POSITION_TYPE_SELL):
        order_type = mt5.ORDER_TYPE_BUY
        price = float(tick.ask)
    else:
        return False, f"ticket {ticket}: unknown position type {ptype}"
    if price <= 0:
        return False, f"ticket {ticket}: invalid market price"

    base_request = {
        "action": mt5.TRADE_ACTION_DEAL,
        "symbol": symbol_name,
        "volume": volume,
        "type": order_type,
        "position": ticket,
        "price": price,
        "deviation": int(max(1, deviation)),
        "magic": BOT_MAGIC,
        "comment": _safe_trade_comment("SAPHATECH QEXIT"),
        "type_time": mt5.ORDER_TIME_GTC,
    }

    errors = []
    for fill_mode in _allowed_fill_modes(symbol_name):
        result = mt5.order_send(dict(base_request, type_filling=fill_mode))
        if result is None:
            errors.append(f"fill={fill_mode}: order_send failed: {mt5.last_error()}")
            continue
        retcode = int(getattr(result, "retcode", -1))
        comment = str(getattr(result, "comment", "") or "")
        if retcode in (
            getattr(mt5, "TRADE_RETCODE_DONE", 10009),
            getattr(mt5, "TRADE_RETCODE_DONE_PARTIAL", 10010),
            getattr(mt5, "TRADE_RETCODE_PLACED", 10008),
        ):
            return True, f"ticket {ticket}: QUICK EXIT accepted (retcode={retcode}, fill={fill_mode}, comment={comment})"
        errors.append(f"fill={fill_mode}: retcode={retcode}, comment={comment}")
        if retcode == getattr(mt5, "TRADE_RETCODE_INVALID_FILL", 10030):
            continue
    return False, f"ticket {ticket}: QUICK EXIT failed | " + " | ".join(errors[-6:])


def close_all_positions_at_profit_target(symbol: Optional[str] = None, target_usd: float = 6.0, deviation: int = 500,
                                         random_target: bool = False, random_min: float = 1.0,
                                         random_max: float = 6.0) -> LiveOrderResult:
    """Close SAPHATECH bot positions immediately when each reaches its profit target.

    A position is eligible when floating profit + swap is at or above its target.
    Random targets are assigned once per ticket. Closing uses fresh market quotes,
    broker-supported filling modes, and retries partial/failed closes on the next
    monitoring cycle.
    """
    connect()
    positions = bot_positions(symbol)
    if not positions:
        all_positions = open_positions(symbol)
        if all_positions:
            symbols = sorted({str(getattr(p, "symbol", "?")) for p in all_positions})
            return LiveOrderResult(False, f"MT5 has {len(all_positions)} open position(s) [{', '.join(symbols)}], but none are tagged as SAPHATECH BOT positions.")
        return LiveOrderResult(False, "No live positions are currently open.")

    target_usd = max(0.10, float(target_usd))
    lo = max(0.10, float(random_min))
    hi = max(lo, float(random_max))
    closed = 0
    watched = 0
    errors = []

    open_tickets = {int(getattr(p, "ticket", 0) or 0) for p in positions}
    for ticket in list(_RANDOM_GLOBAL_TARGETS):
        if ticket not in open_tickets:
            _RANDOM_GLOBAL_TARGETS.pop(ticket, None)

    for position in positions:
        ticket = int(getattr(position, "ticket", 0) or 0)
        if not ticket:
            continue
        watched += 1
        current_profit = (float(getattr(position, "profit", 0.0) or 0.0) +
                          float(getattr(position, "swap", 0.0) or 0.0))

        if random_target:
            if ticket not in _RANDOM_GLOBAL_TARGETS:
                _RANDOM_GLOBAL_TARGETS[ticket] = round(random.uniform(lo, hi), 2)
            effective_target = float(_RANDOM_GLOBAL_TARGETS[ticket])
        else:
            effective_target = target_usd

        if current_profit + 1e-9 < effective_target:
            continue

        ok, message = _quick_close_position_at_market(position, deviation=max(1000, int(deviation)))
        if ok:
            closed += 1
        else:
            errors.append(message)

    mode_label = (f"RANDOM ${lo:.2f}-${hi:.2f}" if random_target else f"${target_usd:.2f}")
    if closed and not errors:
        return LiveOrderResult(True, f"AUTO-CLOSE ({mode_label}): closed {closed} position(s) at target.")
    if closed and errors:
        return LiveOrderResult(True, f"AUTO-CLOSE ({mode_label}): closed {closed} position(s); retrying failed close(s): {errors[0]}")
    if errors:
        return LiveOrderResult(False, f"AUTO-CLOSE ({mode_label}): target reached but close failed — {errors[0]}")
    if watched:
        max_profit = max((float(getattr(p, "profit", 0.0) or 0.0) + float(getattr(p, "swap", 0.0) or 0.0)) for p in positions)
        return LiveOrderResult(False, f"Watching {watched} position(s). Highest current profit: ${max_profit:.2f}; target mode: {mode_label}.")
    return LiveOrderResult(False, "No eligible SAPHATECH positions are currently open.")

def close_bot_positions_at_per_position_targets(symbol: Optional[str] = None, deviation: int = 50, exclude_tickets=None) -> LiveOrderResult:
    """Close individual SAPHATECH positions when each reaches its lot-based profit target."""
    connect()
    positions = bot_positions(symbol)
    if not positions:
        return LiveOrderResult(False, "No SAPHATECH positions to monitor.")
    excluded = {int(t) for t in (exclude_tickets or [])}

    closed = 0
    watched = 0
    errors = []

    # Remove remembered random targets for tickets that are no longer open.
    open_tickets = {int(getattr(p, "ticket", 0) or 0) for p in positions}
    for ticket in list(_RANDOM_POSITION_TARGETS):
        if ticket not in open_tickets:
            _RANDOM_POSITION_TARGETS.pop(ticket, None)

    for position in positions:
        ticket = int(getattr(position, "ticket", 0) or 0)
        if ticket in excluded:
            continue
        volume = float(getattr(position, "volume", 0.0) or 0.0)
        ticket = int(getattr(position, "ticket", 0) or 0)
        target = per_position_profit_target(volume, ticket=ticket)
        if target is None:
            continue
        watched += 1
        current_profit = (float(getattr(position, "profit", 0.0) or 0.0) +
                          float(getattr(position, "swap", 0.0) or 0.0))
        if current_profit < target:
            continue

        symbol_name = str(getattr(position, "symbol", symbol or ""))
        tick = mt5.symbol_info_tick(symbol_name)
        if tick is None:
            errors.append(f"ticket {position.ticket}: no live tick")
            continue

        if int(position.type) == int(mt5.POSITION_TYPE_BUY):
            order_type = mt5.ORDER_TYPE_SELL
            price = float(tick.bid)
        else:
            order_type = mt5.ORDER_TYPE_BUY
            price = float(tick.ask)

        base_request = {
            "action": mt5.TRADE_ACTION_DEAL,
            "symbol": symbol_name,
            "volume": volume,
            "type": order_type,
            "position": int(position.ticket),
            "price": price,
            "deviation": deviation,
            "magic": BOT_MAGIC,
            "comment": _safe_trade_comment("SAPHATECH POS PROFIT"),
            "type_time": mt5.ORDER_TIME_GTC,
        }

        sent = False
        fill_errors = []
        for fill_mode in _allowed_fill_modes(symbol_name):
            request = dict(base_request, type_filling=fill_mode)
            check = mt5.order_check(request)
            if check is None:
                fill_errors.append(f"fill={fill_mode}: order_check failed: {mt5.last_error()}")
                continue
            check_code = getattr(check, "retcode", 0)
            if check_code not in (0, mt5.TRADE_RETCODE_DONE):
                fill_errors.append(f"fill={fill_mode}: pre-check retcode={check_code}, comment={getattr(check, 'comment', '')}")
                continue

            result = mt5.order_send(request)
            if result is not None and result.retcode == mt5.TRADE_RETCODE_DONE:
                closed += 1
                sent = True
                break
            if result is None:
                fill_errors.append(f"fill={fill_mode}: order_send failed: {mt5.last_error()}")
            else:
                fill_errors.append(f"fill={fill_mode}: retcode={result.retcode}, comment={result.comment}")

        if not sent:
            errors.append(f"ticket {position.ticket}: " + " | ".join(fill_errors))

    if closed and not errors:
        return LiveOrderResult(True, f"PER-POSITION PROFIT: closed {closed} position(s) at their lot-based target.")
    if closed and errors:
        return LiveOrderResult(True, f"PER-POSITION PROFIT: closed {closed} position(s); some closes failed: {errors[0]}")
    if watched:
        return LiveOrderResult(False, "No per-position profit target was reached." + (f" First close error: {errors[0]}" if errors else ""))
    return LiveOrderResult(False, "No positions are within the configured 0.01–0.50 lot per-position target range.")



def close_existing_bot_positions_at_target(symbol: Optional[str] = None, target_usd: float = 6.0,
                                            tickets=None, deviation: int = 50) -> LiveOrderResult:
    """Close positions that were already open when the bot started once each reaches target_usd.

    Only SAPHATECH positions (magic 26092301) are eligible. If ``tickets`` is
    supplied, only those existing tickets are managed. The target is applied
    per position using floating profit + swap.
    """
    connect()
    wanted = {int(t) for t in (tickets or [])}
    if not wanted:
        return LiveOrderResult(False, "No existing SAPHATECH positions were registered at bot start.")

    # Explicitly registered existing positions may have been opened manually or
    # by an older bot build, so do NOT filter them by the current magic number.
    positions = [p for p in open_positions(symbol) if int(getattr(p, "ticket", 0) or 0) in wanted]
    if not positions:
        return LiveOrderResult(False, "No registered existing positions are currently open.")

    target_usd = max(0.01, float(target_usd))
    closed = 0
    watched = 0
    errors = []

    for position in positions:
        watched += 1
        current_profit = (float(getattr(position, "profit", 0.0) or 0.0) +
                          float(getattr(position, "swap", 0.0) or 0.0))
        if current_profit < target_usd:
            continue

        symbol_name = str(getattr(position, "symbol", symbol or ""))
        tick = mt5.symbol_info_tick(symbol_name)
        if tick is None:
            errors.append(f"ticket {position.ticket}: no live tick")
            continue

        if int(position.type) == int(mt5.POSITION_TYPE_BUY):
            order_type = mt5.ORDER_TYPE_SELL
            price = float(tick.bid)
        else:
            order_type = mt5.ORDER_TYPE_BUY
            price = float(tick.ask)

        base_request = {
            "action": mt5.TRADE_ACTION_DEAL,
            "symbol": symbol_name,
            "volume": float(position.volume),
            "type": order_type,
            "position": int(position.ticket),
            "price": price,
            "deviation": deviation,
            "magic": BOT_MAGIC,
            "comment": _safe_trade_comment("SAPHATECH EXIST PROFIT"),
            "type_time": mt5.ORDER_TIME_GTC,
        }

        sent = False
        fill_errors = []
        for fill_mode in _allowed_fill_modes(symbol_name):
            request = dict(base_request, type_filling=fill_mode)
            check = mt5.order_check(request)
            if check is None:
                fill_errors.append(f"fill={fill_mode}: order_check failed: {mt5.last_error()}")
                continue
            check_code = getattr(check, "retcode", 0)
            if check_code not in (0, mt5.TRADE_RETCODE_DONE):
                fill_errors.append(f"fill={fill_mode}: pre-check retcode={check_code}, comment={getattr(check, 'comment', '')}")
                continue

            result = mt5.order_send(request)
            if result is not None and result.retcode == mt5.TRADE_RETCODE_DONE:
                closed += 1
                sent = True
                break
            if result is None:
                fill_errors.append(f"fill={fill_mode}: order_send failed: {mt5.last_error()}")
            else:
                fill_errors.append(f"fill={fill_mode}: retcode={result.retcode}, comment={result.comment}")

        if not sent:
            errors.append(f"ticket {position.ticket}: " + " | ".join(fill_errors))

    if closed and not errors:
        return LiveOrderResult(True, f"EXISTING POSITION TARGET: closed {closed} position(s) at ${target_usd:.2f} each.")
    if closed and errors:
        return LiveOrderResult(True, f"EXISTING POSITION TARGET: closed {closed} position(s); some closes failed: {errors[0]}")
    if watched:
        return LiveOrderResult(False, f"No existing-position target reached ($${target_usd:.2f}).".replace("$$", "$") + (f" First close error: {errors[0]}" if errors else ""))
    return LiveOrderResult(False, "No registered existing positions are currently open.")


def normalize_volume(symbol: str, volume: float, min_lot: float = MIN_BOT_LOT, max_lot: float = MAX_BOT_LOT) -> float:
    info = mt5.symbol_info(symbol)
    if info is None:
        raise RuntimeError(f"No symbol info for {symbol}")
    step = float(info.volume_step)
    vmin = float(info.volume_min)
    vmax = float(info.volume_max)
    if step <= 0:
        return max(vmin, min(vmax, volume))
    # Bot-supported range: 0.01–0.10 lots, while respecting the broker's
    # minimum/maximum and volume step for the selected symbol.
    volume = max(MIN_BOT_LOT, min(MAX_BOT_LOT, volume))
    volume = math.floor(volume / step) * step
    volume = max(vmin, min(vmax, volume))
    digits = max(0, len(str(step).split(".")[-1].rstrip("0"))) if "." in str(step) else 0
    return round(volume, digits)


def risk_based_volume(symbol: str, side: str, entry: float, stop: float, risk_money: float,
                      min_lot: float = MIN_BOT_LOT, max_lot: float = MAX_BOT_LOT) -> float:
    """Calculate volume from broker tick economics using order_calc_profit."""
    if risk_money <= 0 or entry == stop:
        raise ValueError("Risk money and stop distance must be positive.")
    order_type = mt5.ORDER_TYPE_BUY if side == "BUY" else mt5.ORDER_TYPE_SELL
    one_lot_loss = abs(float(mt5.order_calc_profit(order_type, symbol, 1.0, entry, stop) or 0.0))
    if one_lot_loss <= 0:
        raise RuntimeError("Could not calculate broker-specific stop-loss risk.")
    return normalize_volume(symbol, risk_money / one_lot_loss, min_lot=min_lot, max_lot=max_lot)


def place_manual_market_order(symbol: str, side: str, volume: float, stop: float = 0.0, tp: float = 0.0,
                              deviation: int = 50, comment: str = "SAPHATECH PRO BOT MANUAL") -> LiveOrderResult:
    """Send one manual market order at the current MT5 price using the selected volume.

    This path does not depend on an AI signal or entry trigger. Stop-loss/take-profit
    are optional (0 means no SL/TP); broker-supported filling modes are tried safely.
    """
    connect()
    acct = mt5.account_info()
    if acct is None:
        return LiveOrderResult(False, f"Account unavailable: {mt5.last_error()}")

    # Fail early with a clear message when MT5 client/account trading permission is off.
    terminal = mt5.terminal_info()
    if terminal is not None and hasattr(terminal, "trade_allowed") and not bool(terminal.trade_allowed):
        return LiveOrderResult(False, "MT5 Algo Trading is disabled in the client. Enable Algo Trading/AutoTrading in MT5, then try again.")
    if hasattr(acct, "trade_allowed") and not bool(acct.trade_allowed):
        return LiveOrderResult(False, "The MT5 trading account does not currently allow trading. Check the Exness account/login permissions.")
    if hasattr(acct, "trade_expert") and not bool(acct.trade_expert):
        return LiveOrderResult(False, "The MT5 account is blocking Expert/algorithmic trading. Check the account's trading permissions.")

    symbol = str(symbol).strip()
    side = str(side).upper().strip()
    if side not in ("BUY", "SELL"):
        return LiveOrderResult(False, "Side must be BUY or SELL.")

    tick = mt5.symbol_info_tick(symbol)
    info = mt5.symbol_info(symbol)
    if tick is None or info is None:
        return LiveOrderResult(False, f"No live quote/symbol info for {symbol}")

    disabled_mode = getattr(mt5, "SYMBOL_TRADE_MODE_DISABLED", None)
    if disabled_mode is not None and getattr(info, "trade_mode", None) == disabled_mode:
        return LiveOrderResult(False, f"{symbol} is not tradeable in MT5 right now.")

    try:
        requested = float(volume)
    except (TypeError, ValueError):
        return LiveOrderResult(False, "Invalid manual lot size.")
    if requested <= 0:
        return LiveOrderResult(False, "Manual lot size must be greater than 0.")

    vmin = float(getattr(info, "volume_min", 0.0) or 0.0)
    vmax = float(getattr(info, "volume_max", 0.0) or 0.0)
    vstep = float(getattr(info, "volume_step", 0.01) or 0.01)
    if vmin <= 0:
        vmin = MIN_BOT_LOT
    if vmax <= 0:
        vmax = max(vmin, MAX_BOT_LOT)
    if requested < vmin - 1e-9 or requested > vmax + 1e-9:
        return LiveOrderResult(False, f"Lot {requested:.2f} is outside broker range {vmin:.2f}–{vmax:.2f}.")

    # Normalize to broker volume step without increasing the user's request.
    steps = math.floor((requested - vmin + 1e-12) / max(vstep, 1e-9))
    volume_norm = vmin + max(0, steps) * vstep
    volume_norm = min(volume_norm, vmax)
    decimals = max(0, int(round(-math.log10(vstep))) if vstep < 1 else 0)
    volume_norm = round(volume_norm, decimals)

    if side == "BUY":
        price = float(tick.ask)
        order_type = mt5.ORDER_TYPE_BUY
        if stop and stop >= price:
            return LiveOrderResult(False, "Invalid BUY stop-loss: it must be below the current ask.")
        if tp and tp <= price:
            return LiveOrderResult(False, "Invalid BUY take-profit: it must be above the current ask.")
    else:
        price = float(tick.bid)
        order_type = mt5.ORDER_TYPE_SELL
        if stop and stop <= price:
            return LiveOrderResult(False, "Invalid SELL stop-loss: it must be above the current bid.")
        if tp and tp >= price:
            return LiveOrderResult(False, "Invalid SELL take-profit: it must be below the current bid.")

    base_request = {
        "action": mt5.TRADE_ACTION_DEAL,
        "symbol": symbol,
        "volume": volume_norm,
        "type": order_type,
        "price": price,
        "sl": float(stop or 0.0),
        "tp": float(tp or 0.0),
        "deviation": int(deviation),
        "magic": BOT_MAGIC,
        "comment": _safe_trade_comment(comment),
        "type_time": mt5.ORDER_TIME_GTC,
    }

    errors = []
    fill_modes = _allowed_fill_modes(symbol)

    def _attempt(request, label):
        for fill_mode in fill_modes:
            req = dict(request, type_filling=fill_mode)
            check = mt5.order_check(req)
            if check is None:
                errors.append(f"{label} fill={fill_mode}: order_check failed: {mt5.last_error()}")
                continue
            check_code = getattr(check, "retcode", 0)
            if check_code not in (0, mt5.TRADE_RETCODE_DONE):
                errors.append(f"{label} fill={fill_mode}: pre-check retcode={check_code}, comment={getattr(check, 'comment', '')}")
                # MT5 10016 = Invalid stops.
                # Caller may retry the same market order without SL/TP.
                continue
            result = mt5.order_send(req)
            if result is None:
                errors.append(f"{label} fill={fill_mode}: order_send failed: {mt5.last_error()}")
                continue
            if result.retcode == mt5.TRADE_RETCODE_DONE:
                return result
            errors.append(f"{label} fill={fill_mode}: retcode={result.retcode}, comment={result.comment}")
        return None

    result = _attempt(base_request, "with-stops")
    if result is not None:
        return LiveOrderResult(True, f"MANUAL {side} opened: {volume_norm} lots at {price}", result.order or result.deal)

    # A broker can reject calculated SL/TP with 10016 even when the market order itself is valid.
    # Retry once without stops so the manual BUY/SELL button is not blocked by an invalid stop distance.
    invalid_stops_seen = any("retcode=10016" in msg for msg in errors)
    if invalid_stops_seen and (base_request.get("sl", 0.0) or base_request.get("tp", 0.0)):
        no_stops_request = dict(base_request, sl=0.0, tp=0.0)
        result = _attempt(no_stops_request, "no-stops-fallback")
        if result is not None:
            return LiveOrderResult(
                True,
                f"MANUAL {side} opened: {volume_norm} lots at {price} (SL/TP removed because MT5 rejected the requested stops as invalid).",
                result.order or result.deal,
            )

    return LiveOrderResult(False, "Manual order rejected after filling-mode checks: " + " | ".join(errors))


def place_market_order(symbol: str, side: str, stop: float, tp: float, risk_percent: float,
                       max_positions: int = 10, deviation: int = 50, comment: str = "SAPHATECH PRO BOT",
                       auto_lot: bool = True, fixed_volume: Optional[float] = None,
                       lot_min: float = MIN_BOT_LOT, lot_max: float = MAX_BOT_LOT) -> LiveOrderResult:
    connect()
    acct = mt5.account_info()
    if acct is None:
        return LiveOrderResult(False, f"Account unavailable: {mt5.last_error()}")
    positions = open_positions(symbol)
    if len(positions) >= max_positions:
        return LiveOrderResult(False, f"Position limit reached: {len(positions)}/{max_positions}")

    info = mt5.symbol_info_tick(symbol)
    if info is None:
        return LiveOrderResult(False, f"No live tick for {symbol}")
    side = side.upper()
    if side == "BUY":
        price = float(info.ask)
        order_type = mt5.ORDER_TYPE_BUY
        if stop >= price or tp <= price:
            return LiveOrderResult(False, "Invalid BUY SL/TP relative to current ask.")
    elif side == "SELL":
        price = float(info.bid)
        order_type = mt5.ORDER_TYPE_SELL
        if stop <= price or tp >= price:
            return LiveOrderResult(False, "Invalid SELL SL/TP relative to current bid.")
    else:
        return LiveOrderResult(False, "Side must be BUY or SELL.")

    if auto_lot:
        risk_money = float(acct.equity) * float(risk_percent) / 100.0
        volume = risk_based_volume(symbol, side, price, stop, risk_money, min_lot=lot_min, max_lot=lot_max)
    else:
        if fixed_volume is None:
            return LiveOrderResult(False, "Fixed lot mode requires a lot size.")
        volume = normalize_volume(symbol, float(fixed_volume), min_lot=lot_min, max_lot=lot_max)
    if volume <= 0:
        return LiveOrderResult(False, "Calculated/requested volume is zero.")

    base_request = {
        "action": mt5.TRADE_ACTION_DEAL,
        "symbol": symbol,
        "volume": volume,
        "type": order_type,
        "price": price,
        "sl": float(stop),
        "tp": float(tp),
        "deviation": deviation,
        "magic": BOT_MAGIC,
        "comment": _safe_trade_comment(comment),
        "type_time": mt5.ORDER_TIME_GTC,
    }

    errors = []
    for fill_mode in _allowed_fill_modes(symbol):
        request = dict(base_request, type_filling=fill_mode)
        check = mt5.order_check(request)
        if check is None:
            errors.append(f"fill={fill_mode}: order_check failed: {mt5.last_error()}")
            continue
        check_code = getattr(check, "retcode", 0)
        # 0 and TRADE_RETCODE_DONE are accepted success values for order_check.
        if check_code not in (0, mt5.TRADE_RETCODE_DONE):
            errors.append(f"fill={fill_mode}: pre-check retcode={check_code}, comment={getattr(check, 'comment', '')}")
            continue

        result = mt5.order_send(request)
        if result is None:
            errors.append(f"fill={fill_mode}: order_send failed: {mt5.last_error()}")
            continue
        if result.retcode == mt5.TRADE_RETCODE_DONE:
            sizing = "auto" if auto_lot else "fixed"
            return LiveOrderResult(True, f"LIVE {side} opened: {volume} lots at {price} ({sizing} lot sizing)", result.order or result.deal)

        errors.append(f"fill={fill_mode}: retcode={result.retcode}, comment={result.comment}")
        # If the broker says the filling mode is unsupported, try the next
        # broker-advertised mode. Other rejection reasons are still reported
        # but do not prevent trying a compatible advertised mode.

    return LiveOrderResult(False, "Order rejected after filling-mode checks: " + " | ".join(errors))



def auto_position_count(signal_strength: int, max_positions: int) -> int:
    """Map confirmed multi-timeframe alignment to an automatic position count.

    3/4 aligned timeframes -> half of the configured maximum (minimum 1).
    4/4 aligned timeframes -> the configured maximum.
    """
    max_positions = max(1, int(max_positions))
    if signal_strength >= 4:
        return max_positions
    if signal_strength >= 3:
        return max(1, math.ceil(max_positions / 2))
    return 0


def place_market_orders(symbol: str, side: str, stop: float, tp: float, risk_percent: float,
                        max_positions: int = 10, signal_strength: int = 3,
                        deviation: int = 50, comment: str = "SAPHATECH PRO BOT AUTO",
                        auto_lot: bool = True, fixed_volume: Optional[float] = None,
                        lot_min: float = MIN_BOT_LOT, lot_max: float = MAX_BOT_LOT) -> LiveOrderResult:
    """Open the automatically selected number of positions.

    The configured risk percentage is treated as the total risk budget for the
    batch, so it is divided across positions rather than applying the full
    percentage to every position.
    """
    connect()
    current = len(open_positions(symbol))
    target = min(max(1, int(max_positions)),
                 current + auto_position_count(signal_strength, max_positions))
    needed = max(0, target - current)

    if needed == 0:
        return LiveOrderResult(False, f"Auto position target already reached: {current}/{max_positions}")

    per_position_risk = float(risk_percent) / needed
    opened = []
    errors = []
    for _ in range(needed):
        result = place_market_order(
            symbol, side, stop, tp, per_position_risk,
            max_positions=max_positions, deviation=deviation, comment=comment,
            auto_lot=auto_lot, fixed_volume=fixed_volume, lot_min=lot_min, lot_max=lot_max
        )
        if result.ok:
            opened.append(result)
        else:
            errors.append(result.message)
            break

    if opened and not errors:
        return LiveOrderResult(
            True,
            f"AUTO POSITION: opened {len(opened)} position(s); total {current + len(opened)}/{max_positions}. "
            f"Risk budget {risk_percent:.2f}% split across this batch."
        )
    if opened and errors:
        return LiveOrderResult(
            True,
            f"AUTO POSITION: opened {len(opened)} position(s); total {current + len(opened)}/{max_positions}. "
            f"Stopped after broker/risk rejection: {errors[0]}"
        )
    return LiveOrderResult(False, errors[0] if errors else "No positions opened.")


def _allowed_fill_modes(symbol: str):
    """Return broker-supported MT5 filling modes in a safe order.

    MT5 ``symbol_info().filling_mode`` is a bit mask, not always a single
    ORDER_FILLING_* value.  RETURN is also not allowed for some Market
    Execution symbols, so do not blindly send it.
    """
    info = mt5.symbol_info(symbol)
    if info is None:
        raise RuntimeError(f"No symbol info for {symbol}")

    mask = int(getattr(info, "filling_mode", 0) or 0)
    execution = getattr(info, "trade_exemode", None)
    market_execution = getattr(mt5, "SYMBOL_TRADE_EXECUTION_MARKET", None)

    modes = []
    # For Market Execution, RETURN is not permitted by MT5.
    if market_execution is not None and execution == market_execution:
        if mask & 2:
            modes.append(mt5.ORDER_FILLING_IOC)
        if mask & 1:
            modes.append(mt5.ORDER_FILLING_FOK)
    else:
        if mask & 2:
            modes.append(mt5.ORDER_FILLING_IOC)
        if mask & 1:
            modes.append(mt5.ORDER_FILLING_FOK)
        # RETURN is generally appropriate for non-market execution.
        modes.append(mt5.ORDER_FILLING_RETURN)

    # Some broker builds expose filling_mode as a direct enum rather than a
    # bit mask. Keep that as a fallback.
    direct = getattr(info, "filling_mode", None)
    for mode in (direct, mt5.ORDER_FILLING_IOC, mt5.ORDER_FILLING_FOK):
        if mode in (mt5.ORDER_FILLING_FOK, mt5.ORDER_FILLING_IOC, mt5.ORDER_FILLING_RETURN) and mode not in modes:
            modes.append(mode)

    return modes or [mt5.ORDER_FILLING_IOC]


def info_fill_mode(symbol: str):
    return _allowed_fill_modes(symbol)[0]
