"""
SAPHATECH PRO BOT v4 paper broker.

Simulates order submission and management without contacting a broker.
Use this before connecting any live execution adapter.
"""

from dataclasses import dataclass
from datetime import datetime


@dataclass
class PaperPosition:
    ticket: int
    symbol: str
    side: str
    volume: float
    entry: float
    stop: float
    tp: float
    opened_at: str


class PaperBroker:
    def __init__(self):
        self.positions = []
        self.next_ticket = 100001

    def open_position(self, symbol, side, volume, entry, stop, tp):
        pos = PaperPosition(
            self.next_ticket, symbol, side, volume, entry, stop, tp,
            datetime.now().isoformat(timespec="seconds")
        )
        self.next_ticket += 1
        self.positions.append(pos)
        return pos

    def close_all(self):
        closed = self.positions[:]
        self.positions.clear()
        return closed

    def open_count(self, symbol=None):
        if symbol is None:
            return len(self.positions)
        return sum(p.symbol == symbol for p in self.positions)
