"""
SAPHATECH PRO BOT v6 continuous paper-trading engine.

It consumes completed M5 candles from CSV files and simulates:
- signal generation
- one position at a time
- SL/TP management
- daily loss lockout
- maximum trades per day
- spread filter
- trade journal

No broker API is used.
"""

from dataclasses import dataclass, asdict
from datetime import date
import json
from pathlib import Path
import pandas as pd

from trading_ai import analyze_market


@dataclass
class PaperTrade:
    id: int
    date: str
    side: str
    entry: float
    stop: float
    tp: float
    risk_amount: float
    status: str = "OPEN"
    exit: float = None
    pnl: float = 0.0
    exit_reason: str = ""


class PaperEngine:
    def __init__(
        self,
        balance=10.0,
        risk_percent=1.0,
        max_daily_loss_percent=3.0,
        max_trades_per_day=3,
        max_spread_points=80.0,
    ):
        self.start_balance = balance
        self.balance = balance
        self.risk_percent = risk_percent
        self.max_daily_loss_percent = max_daily_loss_percent
        self.max_trades_per_day = max_trades_per_day
        self.max_spread_points = max_spread_points
        self.current_day = None
        self.day_start_balance = balance
        self.day_trades = 0
        self.next_id = 1
        self.open_trade = None
        self.history = []

    def new_day(self, d):
        if self.current_day != d:
            self.current_day = d
            self.day_start_balance = self.balance
            self.day_trades = 0

    def locked(self):
        loss = self.day_start_balance - self.balance
        return loss >= self.day_start_balance * self.max_daily_loss_percent / 100

    def update_open_trade(self, high, low):
        t = self.open_trade
        if t is None:
            return

        # Conservative rule: if both are touched in one candle, SL wins.
        if t.side == "BUY":
            if low <= t.stop:
                t.exit = t.stop
                t.pnl = -t.risk_amount
                t.status = "CLOSED"
                t.exit_reason = "STOP"
            elif high >= t.tp:
                t.exit = t.tp
                t.pnl = t.risk_amount * 1.5
                t.status = "CLOSED"
                t.exit_reason = "TP"
        else:
            if high >= t.stop:
                t.exit = t.stop
                t.pnl = -t.risk_amount
                t.status = "CLOSED"
                t.exit_reason = "STOP"
            elif low <= t.tp:
                t.exit = t.tp
                t.pnl = t.risk_amount * 1.5
                t.status = "CLOSED"
                t.exit_reason = "TP"

        if t.status == "CLOSED":
            self.balance += t.pnl
            self.history.append(asdict(t))
            self.open_trade = None

    def maybe_open(self, plan, spread_points=0.0):
        if self.open_trade is not None:
            return "SKIP: position already open."
        if self.locked():
            return "LOCKED: daily loss limit reached."
        if self.day_trades >= self.max_trades_per_day:
            return "SKIP: daily trade limit reached."
        if spread_points > self.max_spread_points:
            return "SKIP: spread too high."
        if plan.decision not in ("BUY", "SELL"):
            return "NO TRADE."

        risk = self.balance * self.risk_percent / 100
        self.open_trade = PaperTrade(
            self.next_id,
            str(self.current_day),
            plan.decision,
            plan.entry,
            plan.stop_loss,
            plan.take_profit_1,
            risk,
        )
        self.next_id += 1
        self.day_trades += 1
        return f"PAPER OPEN {plan.decision} #{self.open_trade.id}"

    def stats(self):
        closed = pd.DataFrame(self.history)
        if closed.empty:
            return {
                "balance": self.balance,
                "trades": 0,
                "wins": 0,
                "losses": 0,
                "win_rate": 0.0,
                "net_pnl": 0.0,
                "max_drawdown": 0.0,
            }

        pnl = closed["pnl"].astype(float)
        equity = self.start_balance + pnl.cumsum()
        peak = equity.cummax()
        dd = peak - equity

        return {
            "balance": float(self.balance),
            "trades": int(len(closed)),
            "wins": int((pnl > 0).sum()),
            "losses": int((pnl < 0).sum()),
            "win_rate": float((pnl > 0).mean() * 100),
            "net_pnl": float(pnl.sum()),
            "max_drawdown": float(dd.max()),
        }

    def save(self, path="paper_state.json"):
        state = {
            "start_balance": self.start_balance,
            "balance": self.balance,
            "current_day": str(self.current_day),
            "day_start_balance": self.day_start_balance,
            "day_trades": self.day_trades,
            "next_id": self.next_id,
            "open_trade": asdict(self.open_trade) if self.open_trade else None,
            "history": self.history,
        }
        Path(path).write_text(json.dumps(state, indent=2), encoding="utf-8")
