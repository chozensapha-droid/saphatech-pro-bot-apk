"""
Hard risk controls for SAPHATECH PRO BOT v4.

These checks are intentionally broker-agnostic.
"""

from dataclasses import dataclass
from datetime import datetime, date


@dataclass
class RiskConfig:
    risk_percent: float = 1.0
    max_daily_loss_percent: float = 3.0
    max_open_positions: int = 1
    max_spread_points: float = 80.0
    min_reward_risk: float = 1.5


class RiskManager:
    def __init__(self, config: RiskConfig):
        self.config = config
        self.day = date.today()
        self.start_equity = None

    def reset_if_new_day(self, equity):
        today = date.today()
        if today != self.day:
            self.day = today
            self.start_equity = equity
        if self.start_equity is None:
            self.start_equity = equity

    def daily_loss_allowed(self, equity):
        self.reset_if_new_day(equity)
        loss = self.start_equity - equity
        return loss <= self.start_equity * self.config.max_daily_loss_percent / 100

    def can_trade(self, equity, open_positions, spread_points, entry, stop, tp):
        if not self.daily_loss_allowed(equity):
            return False, "Daily loss limit reached."
        if open_positions >= self.config.max_open_positions:
            return False, "Maximum open positions reached."
        if spread_points > self.config.max_spread_points:
            return False, "Spread is too high."
        risk = abs(entry - stop)
        reward = abs(tp - entry)
        if risk <= 0 or reward / risk < self.config.min_reward_risk:
            return False, "Reward/risk requirement not met."
        return True, "Risk checks passed."
