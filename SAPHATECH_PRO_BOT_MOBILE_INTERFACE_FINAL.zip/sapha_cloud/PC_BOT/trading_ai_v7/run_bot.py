"""Simple direct MT5 execution launcher for SAPHATECH PRO BOT.

WARNING: This launcher intentionally mirrors the requested example.  The
placeholder signal is BUY, so running this file can submit a live order.
Replace evaluate_signal() with the real strategy/AI signal before production use.
"""

from live_mt5 import initialize_mt5, send_mt5_order


def evaluate_signal(symbol):
    """Replace this hook with the live strategy/AI evaluation.

    Return "BUY", "SELL", or None.
    """
    return "BUY"


def run_bot():
    if not initialize_mt5():
        return

    symbol = "EURUSD"  # Ensure this matches the active MT5/BOT configuration.
    lot_size = 0.01    # Starting lot size; replace with your auto-lot calculation if needed.

    print("Saphatech Pro Bot active - Multi-directional (BUY & SELL) execution enabled.")

    while True:
        # Your strategy/AI should determine the signal dynamically.
        signal = evaluate_signal(symbol)

        if signal in ["BUY", "SELL"]:
            print(f"Trigger detected: {signal}. Executing position...")
            send_mt5_order(symbol=symbol, action_type=signal, volume=lot_size)

        # This launcher executes one evaluation/order cycle by design.
        # Remove the break for a continuously running implementation.
        break


if __name__ == "__main__":
    run_bot()
