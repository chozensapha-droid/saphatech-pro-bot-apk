"""
SAPHATECH PRO BOT v1
Multi-instrument analysis: XAUUSD, GBPUSD, AUDUSD, USOIL and BTCUSD.
Multi-timeframe H1 -> M30 -> M15 -> M5, with optional M1 candle entry signal.

Educational/paper-trading prototype. It does NOT place live orders.
Feed OHLCV CSV files into analyze_market().
"""

from dataclasses import dataclass
from typing import Dict, Optional
import pandas as pd
import numpy as np


@dataclass
class TradePlan:
    symbol: str
    decision: str
    bias: str
    entry: Optional[float]
    stop_loss: Optional[float]
    take_profit_1: Optional[float]
    take_profit_2: Optional[float]
    position_size: Optional[float]
    risk_amount: float
    reason: str


def _validate(df: pd.DataFrame) -> pd.DataFrame:
    required = {"open", "high", "low", "close"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Missing columns: {sorted(missing)}")
    out = df.copy().dropna().sort_index()
    if len(out) < 60:
        raise ValueError("At least 60 candles are recommended.")
    return out


def indicators(df: pd.DataFrame) -> pd.DataFrame:
    df = _validate(df)
    x = df.copy()

    x["ema20"] = x["close"].ewm(span=20, adjust=False).mean()
    x["ema50"] = x["close"].ewm(span=50, adjust=False).mean()

    delta = x["close"].diff()
    gain = delta.clip(lower=0).rolling(14).mean()
    loss = (-delta.clip(upper=0)).rolling(14).mean()
    rs = gain / loss.replace(0, np.nan)
    x["rsi14"] = 100 - (100 / (1 + rs))

    prev_close = x["close"].shift(1)
    tr = pd.concat(
        [
            x["high"] - x["low"],
            (x["high"] - prev_close).abs(),
            (x["low"] - prev_close).abs(),
        ],
        axis=1,
    ).max(axis=1)
    x["atr14"] = tr.rolling(14).mean()

    x["recent_high"] = x["high"].rolling(20).max().shift(1)
    x["recent_low"] = x["low"].rolling(20).min().shift(1)
    return x


def timeframe_bias(df: pd.DataFrame, closed_candle: bool = True) -> str:
    x = indicators(df).iloc[-2 if closed_candle else -1]
    if x["close"] > x["ema20"] > x["ema50"] and x["rsi14"] >= 52:
        return "BULLISH"
    if x["close"] < x["ema20"] < x["ema50"] and x["rsi14"] <= 48:
        return "BEARISH"
    return "NEUTRAL"


def position_size(
    balance: float,
    risk_percent: float,
    entry: float,
    stop_loss: float,
    contract_size: float = 100.0,
) -> float:
    """Generic CFD/spot-style calculator. Confirm your broker's contract specs."""
    risk_amount = balance * risk_percent / 100
    distance = abs(entry - stop_loss)
    if distance <= 0:
        raise ValueError("Entry and stop-loss must be different.")
    lots = risk_amount / (distance * contract_size)
    # Requested bot lot range: 0.01–0.10.
    return min(0.10, max(0.01, lots))


def analyze_market(
    frames: Dict[str, pd.DataFrame],
    balance: float,
    risk_percent: float = 1.0,
    symbol: str = "XAUUSD",
    candle_movement: bool = True,
    candle_confirmations: int = 1,
    min_body_percent: float = 0.0,
    candle_timeframe: str = "M1",
) -> TradePlan:
    required = ["H1", "M30", "M15", "M5"]
    candle_timeframe = str(candle_timeframe).upper().strip()
    if candle_timeframe not in frames:
        raise ValueError(f"Missing candle timeframe: {candle_timeframe}")
    missing = [tf for tf in required if tf not in frames]
    if missing:
        raise ValueError(f"Missing timeframes: {missing}")

    data = {tf: indicators(frames[tf]) for tf in set(required + [candle_timeframe])}
    decision_pos = -2 if candle_movement else -1
    biases = {tf: timeframe_bias(frames[tf], closed_candle=candle_movement) for tf in required}

    bullish = sum(v == "BULLISH" for v in biases.values())
    bearish = sum(v == "BEARISH" for v in biases.values())

    signal_bar = data[candle_timeframe].iloc[decision_pos]
    m15 = data["M15"].iloc[decision_pos]

    candle_note = ""
    if candle_movement:
        confirmations = max(1, min(3, int(candle_confirmations)))
        body_floor = max(0.0, min(100.0, float(min_body_percent)))
        candle_raw = frames[candle_timeframe].copy()
        if len(candle_raw) < confirmations + 2:
            return TradePlan(symbol, "NO TRADE", "NEUTRAL", None, None, None, None,
                             None, balance * risk_percent / 100, "Not enough closed candle data for candle confirmation.")
        closed = candle_raw.iloc[-(confirmations + 1):-1]
        bullish_candles = []
        bearish_candles = []
        for _, c in closed.iterrows():
            rng = float(c["high"] - c["low"])
            body = abs(float(c["close"] - c["open"]))
            body_pct = (body / rng * 100.0) if rng > 0 else 0.0
            bullish_candles.append(float(c["close"]) > float(c["open"]) and body_pct >= body_floor)
            bearish_candles.append(float(c["close"]) < float(c["open"]) and body_pct >= body_floor)
        candle_buy = all(bullish_candles)
        candle_sell = all(bearish_candles)
        if candle_buy and not candle_sell:
            candle_note = f"Candle movement confirmed BUY: {confirmations} closed {candle_timeframe} candle(s), body >= {body_floor:.0f}%."
        elif candle_sell and not candle_buy:
            candle_note = f"Candle movement confirmed SELL: {confirmations} closed {candle_timeframe} candle(s), body >= {body_floor:.0f}%."
        else:
            return TradePlan(
                symbol, "NO TRADE",
                "BULLISH" if bullish > bearish else "BEARISH" if bearish > bullish else "NEUTRAL",
                None, None, None, None, None,
                balance * risk_percent / 100,
                f"CANDLE MOVEMENT WAIT: last {confirmations} closed {candle_timeframe} candle(s) do not confirm one direction."
            )
    else:
        candle_buy = candle_sell = True
    entry = float(signal_bar["close"])
    atr = float(signal_bar["atr14"])

    if not np.isfinite(atr) or atr <= 0:
        return TradePlan(symbol, "NO TRADE", "NEUTRAL", None, None, None, None,
                         None, balance * risk_percent / 100,
                         "ATR is unavailable.")

    # Conservative alignment rule:
    # H1/M30 establish direction; M15 confirms; M5 times the entry.
    if candle_buy and bullish >= 3 and biases["H1"] == biases["M30"] == "BULLISH":
        stop = min(entry - 1.2 * atr, float(m15["recent_low"]))
        if not np.isfinite(stop) or stop >= entry:
            stop = entry - 1.5 * atr
        risk_distance = entry - stop
        tp1 = entry + 1.5 * risk_distance
        tp2 = entry + 2.0 * risk_distance
        lots = position_size(balance, risk_percent, entry, stop)
        return TradePlan(
            symbol, "BUY", "BULLISH", entry, stop, tp1, tp2, lots,
            balance * risk_percent / 100,
            f"Timeframe alignment: {bullish}/4 bullish; H1 and M30 bullish. {candle_note}"
        )

    if candle_sell and bearish >= 3 and biases["H1"] == biases["M30"] == "BEARISH":
        stop = max(entry + 1.2 * atr, float(m15["recent_high"]))
        if not np.isfinite(stop) or stop <= entry:
            stop = entry + 1.5 * atr
        risk_distance = stop - entry
        tp1 = entry - 1.5 * risk_distance
        tp2 = entry - 2.0 * risk_distance
        lots = position_size(balance, risk_percent, entry, stop)
        return TradePlan(
            symbol, "SELL", "BEARISH", entry, stop, tp1, tp2, lots,
            balance * risk_percent / 100,
            f"Timeframe alignment: {bearish}/4 bearish; H1 and M30 bearish. {candle_note}"
        )

    return TradePlan(
        symbol, "NO TRADE",
        "BULLISH" if bullish > bearish else "BEARISH" if bearish > bullish else "NEUTRAL",
        None, None, None, None, None,
        balance * risk_percent / 100,
        ("M5/M15/M30/H1 are not sufficiently aligned. " + candle_note) if candle_note else "M5/M15/M30/H1 are not sufficiently aligned."
    )


def format_plan(plan: TradePlan) -> str:
    lines = [
        f"{plan.symbol} | DECISION: {plan.decision}",
        f"BIAS: {plan.bias}",
        f"ENTRY: {plan.entry}",
        f"STOP LOSS: {plan.stop_loss}",
        f"TP1: {plan.take_profit_1}",
        f"TP2: {plan.take_profit_2}",
        f"POSITION SIZE: {plan.position_size}",
        f"RISK AMOUNT: {plan.risk_amount:.2f}",
        f"REASON: {plan.reason}",
    ]
    return "\n".join(lines)


if __name__ == "__main__":
    print("SAPHATECH PRO BOT v1 loaded.")
    print("Import analyze_market() and provide H1, M30, M15 and M5 OHLCV DataFrames.")
